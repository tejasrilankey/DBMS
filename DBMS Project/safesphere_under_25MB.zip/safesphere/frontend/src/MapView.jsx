import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { dirUrl, km, kmText, statusText, timeAgo } from "./util.jsx";

const pin = (cls, label = "") =>
  L.divIcon({ className: "", html: `<div class="pin ${cls}">${label}</div>`, iconSize: [26, 26], iconAnchor: [13, 13] });

function node(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

function incidentPopup(i, pos, onHelp) {
  const box = node("div", "pop");
  box.append(node("strong", "", `${i.incident_type} Incident`));
  const d = km(pos.lat, pos.lng, i.latitude, i.longitude);
  const rows = [
    ["Location", d != null ? kmText(d) : i.location || "—"],
    ["Severity", i.severity || "—"],
    ["Reported", timeAgo(i.created_at)],
    ["People affected", i.people_affected ?? "Unknown"],
    ["Status", statusText(i.status)],
  ];
  rows.forEach(([k, v]) => box.append(node("div", "pop-row", `${k}: ${v}`)));
  const actions = node("div", "pop-actions");
  const help = node("button", "btn small primary", "Request Help");
  help.onclick = () => onHelp(i);
  const go = node("a", "btn small", "Get Directions");
  go.href = dirUrl(i.latitude, i.longitude);
  go.target = "_blank";
  go.rel = "noreferrer";
  actions.append(help, go);
  box.append(actions);
  return box;
}

const simple = (title, lines, lat, lng) => {
  const b = node("div", "pop");
  b.append(node("strong", "", title));
  lines.filter(Boolean).forEach((t) => b.append(node("div", "pop-row", t)));
  const go = node("a", "btn small", "Get Directions");
  go.href = dirUrl(lat, lng);
  go.target = "_blank";
  go.rel = "noreferrer";
  b.append(go);
  return b;
};

export const LEGEND = [
  ["pin-red", "Active disaster"], ["pin-orange", "Reported incident"], ["pin-green", "Available volunteer"],
  ["pin-blue", "Shelter"], ["pin-pink", "Hospital"], ["pin-navy", "Emergency service"], ["pin-me", "You"],
];

export default function MapView({ data, pos, onHelp }) {
  const el = useRef(null);
  const map = useRef(null);
  const layer = useRef(null);
  const fitted = useRef(false);

  useEffect(() => {
    map.current = L.map(el.current).setView([pos.lat, pos.lng], 12);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: "© OpenStreetMap" }).addTo(map.current);
    layer.current = L.layerGroup().addTo(map.current);
    fitted.current = false;
    return () => { map.current.remove(); map.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!map.current || !data) return;
    const g = layer.current;
    g.clearLayers();
    const pts = [[pos.lat, pos.lng]];
    const add = (lat, lng, icon, popup, z = 0, fit = true) => {
      if (fit) pts.push([lat, lng]);
      L.marker([lat, lng], { icon, zIndexOffset: z }).bindPopup(popup).addTo(g);
    };
    data.alerts.forEach((a) => {
      if (a.radius_km) L.circle([a.latitude, a.longitude], { radius: a.radius_km * 1000, color: "#d9251d", weight: 1, fillOpacity: 0.07 }).addTo(g);
      add(a.latitude, a.longitude, pin("pin-red", "!"),
        simple(a.title, [`${a.disaster_type} · ${a.severity}`, a.location, a.radius_km ? `Affects ~${a.radius_km} km` : ""], a.latitude, a.longitude), 300, false);
    });
    data.incidents.forEach((i) => add(i.latitude, i.longitude, pin("pin-orange", i.is_sos ? "S" : "i"), incidentPopup(i, pos, onHelp), 400));
    data.volunteers.forEach((v) => add(v.latitude, v.longitude, pin("pin-green", "V"), simple(v.name, [v.skills.join(", ")], v.latitude, v.longitude)));
    data.shelters.forEach((s) => add(s.latitude, s.longitude, pin("pin-blue", "S"),
      simple(s.shelter_name, [s.location, `${s.available_slots}/${s.capacity} slots free`], s.latitude, s.longitude)));
    data.hospitals.forEach((s) => add(s.latitude, s.longitude, pin("pin-pink", "H"),
      simple(s.service_name, [s.location, s.phone && `Call ${s.phone}`], s.latitude, s.longitude)));
    data.services.forEach((s) => add(s.latitude, s.longitude, pin("pin-navy", "E"),
      simple(s.service_name, [s.service_type, s.phone && `Call ${s.phone}`], s.latitude, s.longitude)));
    L.marker([pos.lat, pos.lng], { icon: pin("pin-me"), zIndexOffset: 1000 }).bindPopup(pos.live ? "You are here" : "Default location (allow GPS for accuracy)").addTo(g);
    if (!fitted.current && pts.length > 1) {
      map.current.fitBounds(pts, { padding: [40, 40], maxZoom: 14 });
      fitted.current = true;
    }
  }, [data, pos, onHelp]);

  return <div ref={el} className="map" />;
}
