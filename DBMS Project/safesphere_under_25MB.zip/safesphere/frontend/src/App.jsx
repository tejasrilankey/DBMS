import { useCallback, useEffect, useRef, useState } from "react";
import "./App.css";
import { api, getToken, setToken } from "./api";
import { AlertsView, AssignView, CommandCenter, Dashboard, FamilyView, HelpView, MapPage, ReportsView, ResourcesView,
  ResponseView, SOSView, VerifyView, VolunteerView, useMatches } from "./views.jsx";
import { Badge, DEFAULT_POS, Empty, F, FormModal, HELP_TYPES, INCIDENT_TYPES, Opts, PRIORITIES, timeAgo } from "./util.jsx";

const CITIZEN_NAV = [["dashboard", "Dashboard"], ["alerts", "Alerts"], ["sos", "SOS"], ["map", "Live map"], ["help", "Help requests"],
  ["family", "Family safety"], ["resources", "Shelters & services"]];
const TEAM_NAV = [["command", "Command Center"], ["reports", "Reports"], ["verify", "Verify"], ["assign", "Assign"], ["response", "Response"],
  ["alerts", "Alerts"], ["map", "Live map"], ["resources", "Shelters & services"]];

const EMPTY = { alerts: [], shelters: [], services: [], incidents: [], helps: [], responses: [], contacts: [], notes: [], family: [],
  checkins: [], volunteers: [], profile: null, map: null, stats: null };

function AuthScreen({ onAuth, alerts }) {
  const [mode, setMode] = useState("login");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setBusy(true); setErr("");
    try {
      onAuth(mode === "login" ? await api.login(f.get("email"), f.get("password"))
        : await api.register({ name: f.get("name"), email: f.get("email"), phone: f.get("phone") || null, password: f.get("password"), role: f.get("role") }));
    } catch (x) { setErr(x.message); setBusy(false); }
  };
  return (
    <main className="auth">
      <section className="auth-intro">
        <h1>SafeSphere</h1>
        <p>Disaster alerts, SOS and community response in one place.</p>
        {alerts.slice(0, 2).map((a) => <div className="auth-alert" key={a.disaster_id}><Badge level={a.severity} /> <b>{a.title}</b> <span>{a.location}, {timeAgo(a.alert_time)}</span></div>)}
      </section>
      <form className="auth-card" onSubmit={submit}>
        <div className="tabs" role="tablist">
          <button type="button" role="tab" aria-selected={mode === "login"} className={mode === "login" ? "on" : ""} onClick={() => setMode("login")}>Log in</button>
          <button type="button" role="tab" aria-selected={mode === "register"} className={mode === "register" ? "on" : ""} onClick={() => setMode("register")}>Sign up</button>
        </div>
        {mode === "register" && <F label="Full name"><input name="name" required minLength={2} maxLength={100} /></F>}
        <F label="Email"><input name="email" type="email" required /></F>
        {mode === "register" && <div className="two"><F label="Phone"><input name="phone" maxLength={15} /></F>
          <F label="Join as"><select name="role" defaultValue="citizen"><option value="citizen">Citizen</option><option value="volunteer">Volunteer</option></select></F></div>}
        <F label="Password"><input name="password" type="password" required minLength={6} maxLength={72} /></F>
        {err && <div className="form-error">{err}</div>}
        <button className="btn primary wide" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Log in" : "Create account"}</button>
        {mode === "login" && <div className="demo">Demo: <code>citizen@safesphere.com</code> / citizen123 · <code>volunteer@safesphere.com</code> / volunteer123 · <code>admin@safesphere.com</code> / admin123</div>}
      </form>
    </main>
  );
}

function AssignBody({ req, onDone, run }) {
  const matches = useMatches(req.request_id);
  const [pick, setPick] = useState(null);
  const [msg, setMsg] = useState("");
  return (
    <div className="overlay" onClick={onDone}>
      <div className="modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="Assign volunteer">
        <button className="modal-x" onClick={onDone} aria-label="Close">×</button>
        <h2>Assign volunteer</h2>
        <p className="muted"><Badge level={req.priority} /> {req.request_type} · {req.location}</p>
        {matches === null ? <Empty>Finding best matches…</Empty> : matches.length === 0 ? <Empty>No available volunteers.</Empty> : (
          <ul className="matches">{matches.map((m) => (
            <li key={m.user_id}><label className="check"><input type="radio" name="v" checked={pick === m.user_id} onChange={() => setPick(m.user_id)} />
              <span><b>{m.name}</b> <span className="muted">score {m.score}</span><br /><span className="muted">{m.reasons.join(" · ") || "Available"}</span></span></label></li>))}</ul>)}
        <F label="Message to volunteer (optional)"><input value={msg} onChange={(e) => setMsg(e.target.value)} maxLength={200} /></F>
        <div className="modal-actions"><button className="btn" onClick={onDone}>Cancel</button>
          <button className="btn primary" disabled={!pick} onClick={() => run(() => api.post(`/help-requests/${req.request_id}/assign`, { volunteer_id: pick, message: msg || null }), "Volunteer assigned").then(onDone)}>Assign</button></div>
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(null);
  const [booting, setBooting] = useState(!!getToken());
  const [d, setD] = useState(EMPTY);
  const [pubAlerts, setPubAlerts] = useState([]);
  const [tab, setTab] = useState("dashboard");
  const [modal, setModalState] = useState(null);
  const [toast, setToast] = useState(null);
  const [bell, setBell] = useState(false);
  const [pos, setPos] = useState(DEFAULT_POS);
  const [loadError, setLoadError] = useState("");
  const seen = useRef(null);

  const isAdmin = user?.role === "admin";
  const canRespond = !!user && (user.role === "volunteer" || isAdmin);
  const nav = isAdmin ? TEAM_NAV : [...CITIZEN_NAV, ...(canRespond ? [["volunteer", "Volunteer profile"]] : [])];

  const notify = useCallback((message, type = "ok") => { setToast({ message, type }); setTimeout(() => setToast(null), 4000); }, []);
  const clearSession = useCallback(() => { setToken(null); setUser(null); setD(EMPTY); }, []);
  const setModal = (name, payload) => setModalState(name ? { name, payload } : null);

  const load = useCallback(async () => {
    if (!user) return;
    const q = !isAdmin && pos.live ? `?lat=${pos.lat}&lng=${pos.lng}` : "";
    const jobs = {
      alerts: `/disaster-alerts${q}`, shelters: "/shelters", services: "/emergency-services", stats: "/stats", incidents: "/incidents",
      helps: "/help-requests", responses: "/community-responses", contacts: "/emergency-contacts", notes: "/notifications",
      family: "/checkins/family", checkins: "/checkins/me", map: "/map",
      ...(canRespond ? { profile: "/volunteers/me", volunteers: "/volunteers" } : {}),
    };
    try {
      const keys = Object.keys(jobs);
      const vals = await Promise.all(keys.map((k) => api.get(jobs[k])));
      const next = Object.fromEntries(keys.map((k, i) => [k, vals[i]]));
      setD((o) => ({ ...o, ...next }));
      setLoadError("");
      const top = Math.max(0, ...next.notes.map((n) => n.notification_id));
      if (seen.current !== null) {
        next.notes.filter((n) => n.notification_id > seen.current && !n.is_read).slice(0, 2)
          .forEach((n) => notify(`${n.title}${n.message ? ": " + n.message : ""}`, n.level === "critical" ? "error" : "ok"));
      }
      seen.current = top;
    } catch (e) {
      if (e.status === 401) { clearSession(); notify("Session expired. Please log in again.", "error"); } else setLoadError(e.message);
    }
  }, [user, isAdmin, canRespond, pos.live, pos.lat, pos.lng, clearSession, notify]);

  // first load + "real-time" updates by polling every 8 s
  useEffect(() => { load(); const t = setInterval(load, 8000); return () => clearInterval(t); }, [load]);

  // boot: restore session, or fetch public alerts for the login page
  useEffect(() => {
    (async () => {
      if (getToken()) { try { const u = await api.get("/auth/me"); setUser(u); setTab(u.role === "admin" ? "command" : "dashboard"); } catch { setToken(null); } }
      setBooting(false);
      api.get("/disaster-alerts").then(setPubAlerts).catch(() => {});
    })();
  }, []);

  // location: ask the browser, keep the server's copy fresh (used for location-based alerts)
  useEffect(() => {
    if (!user || !navigator.geolocation) return undefined;
    const ask = () => navigator.geolocation.getCurrentPosition(
      (p) => {
        const lat = +p.coords.latitude.toFixed(4), lng = +p.coords.longitude.toFixed(4);
        setPos((o) => (o.live && o.lat === lat && o.lng === lng ? o : { lat, lng, live: true }));
        api.put("/me/location", { latitude: lat, longitude: lng }).catch(() => {});
      }, () => {}, { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 });
    ask();
    const t = setInterval(ask, 60000);
    return () => clearInterval(t);
  }, [user]);

  const onAuth = (data) => { setToken(data.access_token); seen.current = null; setUser(data.user); setTab(data.user.role === "admin" ? "command" : "dashboard"); notify(`Welcome, ${data.user.name}`); };
  const run = async (fn, ok) => {
    try { const r = await fn(); if (ok) notify(ok); await load(); return r; }
    catch (e) { if (e.status === 401) { clearSession(); notify("Session expired. Please log in again.", "error"); } else notify(e.message, "error"); }
  };
  const del = (path, q, ok) => window.confirm(q) && run(() => api.del(path), ok);
  const respondTo = (r) => {
    const message = window.prompt(`Message for ${r.requester_name || "the requester"} (optional):`, "I can help. On my way.");
    if (message !== null) run(() => api.post("/community-responses", { request_id: r.request_id, response_type: r.request_type.slice(0, 50), message }), "Response sent. Thank you!");
  };
  const setSlots = (s) => {
    const v = window.prompt(`Available slots for ${s.shelter_name} (0-${s.capacity}):`, s.available_slots);
    if (v === null) return;
    const n = Number(v);
    if (!Number.isInteger(n) || n < 0) return notify("Enter a whole number.", "error");
    run(() => api.patch(`/shelters/${s.shelter_id}/slots`, { available_slots: n }), "Shelter updated");
  };
  const markRead = async () => { setBell(!bell); if (!bell && d.notes.some((n) => !n.is_read)) { await api.post("/notifications/read"); load(); } };

  if (booting) return <div className="boot">Loading SafeSphere…</div>;
  if (!user) return <><AuthScreen onAuth={onAuth} alerts={pubAlerts} />{toast && <div className={`toast ${toast.type}`}>{toast.message}</div>}</>;

  const c = { d, user, pos, isAdmin, canRespond, setTab, modal: setModal, notify, run, refresh: load, del, respondTo, setSlots };
  const unread = d.notes.filter((n) => !n.is_read).length;
  const View = { dashboard: Dashboard, alerts: AlertsView, sos: SOSView, map: MapPage, help: HelpView, family: FamilyView, resources: ResourcesView,
    volunteer: VolunteerView, command: CommandCenter, reports: ReportsView, verify: VerifyView, assign: AssignView, response: ResponseView }[tab] || Dashboard;
  const m = modal?.name;
  const P = modal?.payload || {};
  const gps = (f) => ({ latitude: P.latitude ?? (pos.live ? pos.lat : null), longitude: P.longitude ?? (pos.live ? pos.lng : null), location: f.get("location") || null });

  return (
    <div className="shell">
      <aside className="side">
        <div className="brand"><b>SafeSphere</b><span>{isAdmin ? "Response team" : "Citizen"}</span></div>
        <nav aria-label="Main">{nav.map(([id, t]) => <button key={id} className={`${tab === id ? "on" : ""} ${id === "sos" ? "sos-link" : ""}`} onClick={() => setTab(id)}>{t}</button>)}</nav>
      </aside>
      <div className="main">
        <header className="bar">
          <span className="who">{user.name} <span className="tag">{user.role}</span></span>
          <div className="bar-right">
            <div className="bell-wrap">
              <button className="btn small" onClick={markRead} aria-label="Notifications">Notifications{unread > 0 && <span className="count">{unread}</span>}</button>
              {bell && <div className="bell-list">{d.notes.length === 0 ? <div className="muted pad">Nothing yet.</div> : d.notes.map((n) => (
                <div key={n.notification_id} className={`note n-${n.level}`}><b>{n.title}</b><span>{n.message}</span><small>{timeAgo(n.created_at)}</small></div>))}</div>}
            </div>
            <button className="btn small" onClick={() => { clearSession(); seen.current = null; }}>Log out</button>
          </div>
        </header>
        {loadError && <div className="form-error banner">{loadError}</div>}
        <main className="page"><View c={c} /></main>
      </div>

      {m === "report" && (
        <FormModal title="Report incident" subtitle="Response team is notified." submitLabel="Submit report" onClose={() => setModal(null)}
          onSubmit={async (f) => { await api.post("/incidents", { incident_type: f.get("incident_type"), description: f.get("description") || null, severity: f.get("severity"),
            people_affected: f.get("people") ? Number(f.get("people")) : null, disaster_id: f.get("disaster_id") ? Number(f.get("disaster_id")) : null, ...gps(f) });
            setModal(null); notify("Incident submitted"); load(); }}>
          <F label="Incident type"><select name="incident_type"><Opts list={INCIDENT_TYPES} /></select></F>
          <F label="Location"><input name="location" maxLength={150} required placeholder="Where is it?" /></F>
          <div className="two"><F label="Severity"><select name="severity" defaultValue="Medium"><Opts list={["Low", "Medium", "High", "Critical"]} /></select></F>
            <F label="People affected"><input name="people" type="number" min="0" /></F></div>
          <F label="Description"><textarea name="description" rows="3" required /></F>
          {d.alerts.length > 0 && <F label="Related alert (optional)"><select name="disaster_id" defaultValue=""><option value="">None</option>{d.alerts.map((a) => <option key={a.disaster_id} value={a.disaster_id}>{a.title}</option>)}</select></F>}
        </FormModal>)}

      {m === "help" && (
        <FormModal title="Request help" subtitle="Pick the priority that fits. Responders see the most urgent first." submitLabel="Send request" onClose={() => setModal(null)}
          onSubmit={async (f) => { await api.post("/help-requests", { request_type: f.get("request_type"), priority: f.get("priority"), description: f.get("description") || null, ...gps(f) });
            setModal(null); notify("Help request sent"); setTab("help"); load(); }}>
          <F label="What do you need?"><select name="request_type"><Opts list={HELP_TYPES} /></select></F>
          <F label="Priority"><select name="priority" defaultValue="High">{PRIORITIES.map(([p, t]) => <option key={p} value={p}>{p}: {t}</option>)}</select></F>
          <F label="Location"><input name="location" maxLength={150} required defaultValue={P.location || ""} placeholder="Where are you?" /></F>
          <F label="Details"><textarea name="description" rows="3" required /></F>
        </FormModal>)}

      {m === "alert" && (
        <FormModal title="Issue alert" subtitle="Only users inside the radius are notified. Leave coordinates empty for a region-wide notice." submitLabel="Publish alert" onClose={() => setModal(null)}
          onSubmit={async (f) => { const num = (k) => (f.get(k) ? Number(f.get(k)) : null);
            await api.post("/disaster-alerts", { disaster_type: f.get("disaster_type"), title: f.get("title"), severity: f.get("severity"), location: f.get("location"),
              description: f.get("description") || null, latitude: num("latitude"), longitude: num("longitude"), radius_km: num("radius_km"),
              safety_instructions: f.get("safety") || null, evacuation_info: f.get("evac") || null, source: f.get("source") || null, verified: f.get("verified") === "on" });
            setModal(null); notify("Alert published"); load(); }}>
          <div className="two"><F label="Type"><select name="disaster_type"><Opts list={["Flood", "Cyclone", "Earthquake", "Fire", "Landslide", "Other"]} /></select></F>
            <F label="Severity"><select name="severity" defaultValue="Medium"><Opts list={["Low", "Medium", "High", "Critical"]} /></select></F></div>
          <F label="Title"><input name="title" required maxLength={150} /></F>
          <F label="Affected area"><input name="location" required maxLength={150} /></F>
          <div className="three"><F label="Latitude"><input name="latitude" type="number" step="any" defaultValue={pos.lat} /></F>
            <F label="Longitude"><input name="longitude" type="number" step="any" defaultValue={pos.lng} /></F>
            <F label="Radius (km)"><input name="radius_km" type="number" step="any" min="0.1" defaultValue="5" /></F></div>
          <F label="Description"><textarea name="description" rows="2" /></F>
          <F label="Safety instructions"><textarea name="safety" rows="2" /></F>
          <F label="Evacuation information"><textarea name="evac" rows="2" /></F>
          <div className="two"><F label="Source"><input name="source" maxLength={100} defaultValue="SafeSphere Control Room" /></F>
            <label className="check push"><input type="checkbox" name="verified" defaultChecked />Verified</label></div>
        </FormModal>)}

      {m === "shelter" && (
        <FormModal title="Add shelter" submitLabel="Add shelter" onClose={() => setModal(null)}
          onSubmit={async (f) => { const num = (k) => (f.get(k) ? Number(f.get(k)) : null);
            await api.post("/shelters", { shelter_name: f.get("shelter_name"), location: f.get("location"), capacity: Number(f.get("capacity")), available_slots: Number(f.get("available_slots")),
              contact: f.get("contact") || null, latitude: num("latitude"), longitude: num("longitude") });
            setModal(null); notify("Shelter added"); load(); }}>
          <F label="Name"><input name="shelter_name" required maxLength={150} /></F>
          <F label="Location"><input name="location" required maxLength={150} /></F>
          <div className="two"><F label="Capacity"><input name="capacity" type="number" min="0" required /></F><F label="Available slots"><input name="available_slots" type="number" min="0" required /></F></div>
          <div className="three"><F label="Phone"><input name="contact" maxLength={15} /></F><F label="Latitude"><input name="latitude" type="number" step="any" defaultValue={pos.lat} /></F>
            <F label="Longitude"><input name="longitude" type="number" step="any" defaultValue={pos.lng} /></F></div>
        </FormModal>)}

      {m === "contact" && (
        <FormModal title="Add emergency contact" subtitle="Notified when you press SOS or check in." submitLabel="Save contact" onClose={() => setModal(null)}
          onSubmit={async (f) => { await api.post("/emergency-contacts", { contact_name: f.get("contact_name"), relationship: f.get("relationship") || null, phone: f.get("phone") });
            setModal(null); notify("Contact saved"); load(); }}>
          <F label="Name"><input name="contact_name" required maxLength={100} /></F>
          <div className="two"><F label="Relationship"><input name="relationship" maxLength={50} /></F><F label="Phone"><input name="phone" required maxLength={15} /></F></div>
        </FormModal>)}

      {m === "assign" && <AssignBody req={P} run={run} onDone={() => setModal(null)} />}
      {toast && <div className={`toast ${toast.type}`} role="status">{toast.message}</div>}
    </div>
  );
}
