import { useEffect, useMemo, useState } from "react";
import { api } from "./api";
import MapView, { LEGEND } from "./MapView.jsx";
import { Badge, Empty, PRIORITIES, PRIORITY_RANK, SKILLS, SOS_TYPES, dirUrl, km, kmText, statusText, tel, timeAgo } from "./util.jsx";

const dist = (c, it) => km(c.pos.lat, c.pos.lng, it.latitude, it.longitude);
const byPriority = (a, b) => (PRIORITY_RANK[a.priority] ?? 9) - (PRIORITY_RANK[b.priority] ?? 9) || new Date(b.created_at || 0) - new Date(a.created_at || 0);
const isOpen = (r) => r.status === "Pending" || r.status === "Accepted";
const Head = ({ title, sub, children }) => (
  <div className="head"><div><h2>{title}</h2>{sub && <p className="muted">{sub}</p>}</div><div className="head-actions">{children}</div></div>
);

/* ------------------------------------------------------------------ CITIZEN: Dashboard */
export function Dashboard({ c }) {
  const { d, user, pos } = c;
  const active = d.incidents.filter((i) => i.status !== "Resolved");
  const shelter = useMemo(() => [...d.shelters].map((s) => ({ ...s, dist: dist(c, s) })).sort((a, b) => (a.dist ?? 1e9) - (b.dist ?? 1e9))[0], [d.shelters, pos]); // eslint-disable-line react-hooks/exhaustive-deps
  const last = d.checkins[0];
  const top = d.alerts.find((a) => ["High", "Critical"].includes(a.severity)) || d.alerts[0];
  return (
    <>
      <Head title={`Hello, ${user.name}`} sub={pos.live ? "Live location on. Alerts are filtered to where you are." : "Location is off, so a default area is used. Allow GPS for accurate alerts."} />
      <section className="sos-hero">
        <button className="sos-btn" onClick={() => c.setTab("sos")} aria-label="Open emergency SOS"><span>SOS</span></button>
        <div>
          <h3>In an emergency, press SOS</h3>
          <p>Shares your location, alerts your emergency contacts and the response team, and shows the nearest shelters and hospitals.</p>
        </div>
      </section>
      <div className="tiles">
        <button className="tile" onClick={() => c.setTab("alerts")}><b>{d.alerts.length}</b><span>alerts near you</span></button>
        <button className="tile" onClick={() => c.setTab("map")}><b>{active.length}</b><span>active incidents</span></button>
        <button className="tile" onClick={() => c.setTab("resources")}><b>{shelter ? shelter.available_slots : "–"}</b><span>{shelter ? `slots at ${shelter.shelter_name}${shelter.dist != null ? ` (${kmText(shelter.dist)})` : ""}` : "shelter slots"}</span></button>
        <button className="tile" onClick={() => c.setTab("family")}><b>{last ? last.status : "–"}</b><span>{last ? `last check-in ${timeAgo(last.created_at)}` : "no check-in yet"}</span></button>
      </div>
      {top && <AlertCard c={c} a={top} />}
      <div className="row-actions">
        <button className="btn primary" onClick={() => c.modal("help")}>Request help</button>
        <button className="btn" onClick={() => c.modal("report")}>Report incident</button>
        <button className="btn" onClick={() => c.setTab("family")}>I'm safe</button>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ Alerts */
function AlertCard({ c, a }) {
  const d = dist(c, a);
  return (
    <article className={`card alert sev-${a.severity.toLowerCase()}`}>
      <div className="card-top">
        <div><h3>{a.title}</h3><p className="muted">{a.disaster_type} in {a.location}{a.radius_km ? `, affects about ${a.radius_km} km` : ", region-wide"}</p></div>
        <Badge level={a.severity} />
      </div>
      {a.description && <p>{a.description}</p>}
      {a.safety_instructions && <p><b>Safety:</b> {a.safety_instructions}</p>}
      {a.evacuation_info && <p><b>Evacuation:</b> {a.evacuation_info}</p>}
      <div className="card-foot">
        <span className="muted">{timeAgo(a.alert_time)}{d != null && ` · ${kmText(d)}`}</span>
        <span className="muted">{a.source || "SafeSphere"} · {a.verified === false ? "Unverified" : "Verified"}</span>
        {c.isAdmin && <button className="btn small danger" onClick={() => c.del(`/disaster-alerts/${a.disaster_id}`, "Delete this alert?", "Alert deleted")}>Delete</button>}
      </div>
    </article>
  );
}

export function AlertsView({ c }) {
  return (
    <>
      <Head title="Alerts" sub={c.isAdmin ? "All alerts. New alerts notify only people inside the affected area." : "Only alerts that cover your current location are shown."}>
        {c.isAdmin && <button className="btn primary" onClick={() => c.modal("alert")}>Issue alert</button>}
      </Head>
      {c.d.alerts.length === 0 ? <Empty>No alerts for your area right now.</Empty> : c.d.alerts.map((a) => <AlertCard key={a.disaster_id} c={c} a={a} />)}
    </>
  );
}

/* ------------------------------------------------------------------ SOS */
export function SOSView({ c }) {
  const [type, setType] = useState("");
  const [note, setNote] = useState("");
  const [where, setWhere] = useState("");
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState(null);
  const send = async () => {
    if (!type) return c.notify("Choose what kind of emergency this is.", "error");
    setBusy(true);
    try {
      setRes(await api.post("/sos", { sos_type: type, latitude: c.pos.live ? c.pos.lat : null, longitude: c.pos.live ? c.pos.lng : null, location: where || null, description: note || null }));
      c.refresh();
    } catch (e) { c.notify(e.message, "error"); }
    setBusy(false);
  };
  if (res) {
    const Place = ({ p }) => (
      <li><b>{p.name}</b> {p.location && <span className="muted">{p.location}</span>} {p.distance_km != null && <span className="muted">{kmText(p.distance_km)}</span>}
        {p.latitude != null && <a className="btn small" href={dirUrl(p.latitude, p.longitude)} target="_blank" rel="noreferrer">Directions</a>}
        {p.phone && <a className="btn small" href={`tel:${tel(p.phone)}`}>Call</a>}</li>
    );
    return (
      <>
        <Head title="SOS sent" sub={`${res.priority} priority. Stay where it is safe if you can.`} />
        <ol className="flow">
          <li>{c.pos.live ? "Location captured" : "Location not available, please share where you are with contacts"}</li>
          <li>Emergency incident #{res.incident_id} created and help request #{res.request_id} opened</li>
          <li>{res.contacts.length ? `${res.contacts.length} emergency contact(s) listed below` : "No emergency contacts saved yet (add them in Family)"}</li>
          <li>Response team notified ({res.notified_response_team}), plus {res.notified_volunteers} volunteer(s) within 10 km</li>
          <li>Nearby shelters and hospitals below</li>
        </ol>
        {res.contacts.length > 0 && <div className="card"><h3>Contact them directly</h3><ul className="plain">{res.contacts.map((p) => (
          <li key={p.phone}><b>{p.contact_name}</b> <span className="muted">{p.relationship} {p.in_app && "· notified in app"}</span>
            <a className="btn small" href={`tel:${tel(p.phone)}`}>Call</a>
            <a className="btn small" href={`sms:${tel(p.phone)}?body=${encodeURIComponent(`SOS from ${c.user.name}: ${type}. ${c.pos.live ? `https://maps.google.com/?q=${c.pos.lat},${c.pos.lng}` : ""}`)}`}>Text</a></li>))}</ul></div>}
        <div className="grid2">
          <div className="card"><h3>Nearest shelters</h3><ul className="plain">{res.nearby_shelters.map((p) => <Place key={p.id} p={p} />)}</ul></div>
          <div className="card"><h3>Nearest hospitals</h3><ul className="plain">{res.nearby_hospitals.length ? res.nearby_hospitals.map((p) => <Place key={p.id} p={p} />) : <li className="muted">None listed. Call 108.</li>}</ul></div>
        </div>
        <button className="btn" onClick={() => { setRes(null); setType(""); setNote(""); }}>Back</button>
      </>
    );
  }
  return (
    <>
      <Head title="Emergency SOS" sub="Pick the emergency, then send. This alerts people right away, so use it for real emergencies." />
      <div className="chips" role="radiogroup" aria-label="Emergency type">
        {SOS_TYPES.map((t) => <button key={t} role="radio" aria-checked={type === t} className={`chip ${type === t ? "on" : ""}`} onClick={() => setType(t)}>{t}</button>)}
      </div>
      {!c.pos.live && <p className="form-error">Live location is off. Type where you are below.</p>}
      <label className="field"><span>Where are you {c.pos.live ? "(optional)" : ""}</span><input value={where} onChange={(e) => setWhere(e.target.value)} maxLength={150} placeholder="Street, landmark" /></label>
      <label className="field"><span>Anything responders should know (optional)</span><textarea rows="3" value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} /></label>
      <button className="btn sos-send" disabled={busy} onClick={send}>{busy ? "Sending…" : "Send SOS"}</button>
    </>
  );
}

/* ------------------------------------------------------------------ Live map */
export function MapPage({ c }) {
  const m = c.d.map;
  return (
    <>
      <Head title="Live map" sub="Tap a marker for details. Incidents show distance, severity and status." />
      <div className="legend">{LEGEND.map(([cls, t]) => <span key={t}><i className={`pin mini ${cls}`} />{t}</span>)}</div>
      {m ? <MapView data={m} pos={c.pos} onHelp={(i) => c.modal("help", { location: i.location, latitude: i.latitude, longitude: i.longitude })} /> : <Empty>Loading map…</Empty>}
    </>
  );
}

/* ------------------------------------------------------------------ Help requests */
function HelpCard({ c, r }) {
  const { user, d } = c;
  const mine = r.user_id === user.user_id;
  const did = d.responses.some((x) => x.request_id === r.request_id && x.volunteer_id === user.user_id);
  const open = isOpen(r);
  const canUpdate = open && (mine || c.isAdmin || did);
  const dd = dist(c, r);
  return (
    <article className={`card pri-${r.priority.toLowerCase()}`}>
      <div className="card-top">
        <div><h3>{r.request_type}{mine && " (you)"}</h3><p className="muted">{r.requester_name} · {r.location || "No location"}{dd != null && ` · ${kmText(dd)}`}</p></div>
        <Badge level={r.priority} />
      </div>
      {r.description && <p>{r.description}</p>}
      <div className="card-foot">
        <span className="muted">{r.status} · {timeAgo(r.created_at)}</span>
        <span className="btn-row">
          {c.canRespond && !mine && open && !did && <button className="btn small primary" onClick={() => c.respondTo(r)}>Respond</button>}
          {did && <span className="tag">You responded</span>}
          {canUpdate && <button className="btn small" onClick={() => c.run(() => api.patch(`/help-requests/${r.request_id}/status`, { status: "Completed" }), "Marked completed")}>Mark completed</button>}
          {canUpdate && (mine || c.isAdmin) && <button className="btn small danger" onClick={() => c.run(() => api.patch(`/help-requests/${r.request_id}/status`, { status: "Cancelled" }), "Request cancelled")}>Cancel</button>}
        </span>
      </div>
    </article>
  );
}

export function HelpView({ c }) {
  const mineTasks = c.d.responses.filter((r) => r.volunteer_id === c.user.user_id && ["Assigned", "Accepted"].includes(r.status));
  const list = [...c.d.helps].sort((a, b) => Number(isOpen(b)) - Number(isOpen(a)) || byPriority(a, b));
  return (
    <>
      <Head title="Help requests" sub="Most urgent first."><button className="btn primary" onClick={() => c.modal("help")}>Request help</button></Head>
      <div className="levels">{PRIORITIES.map(([p, t]) => <span key={p}><Badge level={p} /> {t}</span>)}</div>
      {mineTasks.length > 0 && (
        <div className="card mission"><h3>Your assignments</h3>
          {mineTasks.map((r) => (
            <div className="row" key={r.response_id}>
              <span><b>{r.request_type}</b> <span className="muted">{r.message}</span></span>
              <span className="btn-row"><Badge level={r.status === "Assigned" ? "High" : "Low"}>{r.status}</Badge>
                {r.status === "Assigned" && <button className="btn small primary" onClick={() => c.run(() => api.patch(`/community-responses/${r.response_id}/status`, { status: "Accepted" }), "Accepted")}>Accept</button>}
                {r.status === "Assigned" && <button className="btn small danger" onClick={() => c.run(() => api.patch(`/community-responses/${r.response_id}/status`, { status: "Declined" }), "Declined")}>Decline</button>}
                <button className="btn small" onClick={() => c.run(() => api.patch(`/community-responses/${r.response_id}/status`, { status: "Completed" }), "Completed")}>Complete</button></span>
            </div>))}
        </div>)}
      {list.length === 0 ? <Empty>No help requests right now.</Empty> : list.map((r) => <HelpCard key={r.request_id} c={c} r={r} />)}
      {!c.canRespond && <p className="muted">Want to help others? Sign up as a volunteer to respond to requests.</p>}
    </>
  );
}

/* ------------------------------------------------------------------ Volunteer profile */
export function VolunteerView({ c }) {
  const p = c.d.profile;
  const [skills, setSkills] = useState([]);
  const [resources, setResources] = useState("");
  const [location, setLocation] = useState("");
  const [available, setAvailable] = useState(true);
  useEffect(() => {
    if (p) { setSkills(p.skills); setResources(p.resources.join(", ")); setLocation(p.location || ""); setAvailable(p.available); }
  }, [p]);
  const save = () => c.run(() => api.put("/volunteers/me", {
    skills, available, location: location || null,
    resources: resources.split(",").map((x) => x.trim()).filter(Boolean),
  }), "Volunteer profile saved");
  return (
    <>
      <Head title="Volunteer profile" sub="The Command Center matches you to requests by skills, resources and distance." />
      <div className="card form-card">
        <div className="card-top"><h3>{c.user.name}</h3><Badge level={available ? "Low" : "Medium"}>{available ? "Available" : "Unavailable"}</Badge></div>
        <fieldset><legend>Skills</legend>
          {SKILLS.map((s) => <label key={s} className="check"><input type="checkbox" checked={skills.includes(s)} onChange={(e) => setSkills(e.target.checked ? [...skills, s] : skills.filter((x) => x !== s))} />{s}</label>)}
        </fieldset>
        <label className="field"><span>Location</span><input value={location} onChange={(e) => setLocation(e.target.value)} maxLength={150} placeholder="City / area" /></label>
        <label className="field"><span>Resources (comma separated)</span><input value={resources} onChange={(e) => setResources(e.target.value)} placeholder="Car, First-aid kit, Water" /></label>
        <label className="check"><input type="checkbox" checked={available} onChange={(e) => setAvailable(e.target.checked)} />Available to help now</label>
        <button className="btn primary" onClick={save}>Save profile</button>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ Family safety */
export function FamilyView({ c }) {
  const [share, setShare] = useState(true);
  const [note, setNote] = useState("");
  const post = (status) => c.run(async () => {
    const r = await api.post("/checkins", { status, note: note || null, share_with_contacts: share });
    c.notify(share ? (r.notified ? `Checked in as ${status}. ${r.notified} contact(s) notified.` : `Checked in as ${status}. None of your contacts use SafeSphere yet, so call them.`) : "Saved privately. No one was told.");
    setNote("");
  });
  const last = c.d.checkins[0];
  return (
    <>
      <Head title="Family safety" sub="Tell the people you trust that you're okay. Your location is never shared here." />
      <div className="card">
        <div className="btn-row big">
          <button className="btn safe" onClick={() => post("Safe")}>I'm safe</button>
          <button className="btn danger solid" onClick={() => post("Needs help")}>I need help</button>
        </div>
        <label className="field"><span>Note (optional)</span><input value={note} onChange={(e) => setNote(e.target.value)} maxLength={300} /></label>
        <label className="check"><input type="checkbox" checked={share} onChange={(e) => setShare(e.target.checked)} />Share this with my emergency contacts</label>
        {last && <p className="muted">Last check-in: {last.status}, {timeAgo(last.created_at)}{last.shared ? "" : " (private)"}</p>}
      </div>
      <div className="card">
        <div className="card-top"><h3>Family members</h3><button className="btn small primary" onClick={() => c.modal("contact")}>Add contact</button></div>
        <p className="muted">A member appears here only if they use SafeSphere, saved your number as their contact, and chose to share.</p>
        {c.d.family.length === 0 ? <Empty>No contacts yet.</Empty> : c.d.family.map((m) => (
          <div className="row" key={m.contact_id}>
            <span><i className={`dot ${m.status === "Safe" ? "ok" : m.status === "Needs help" ? "bad" : "idle"}`} /><b>{m.contact_name}</b> <span className="muted">{m.relationship}</span></span>
            <span className="btn-row"><span className="muted">{m.status}{m.updated_at && `, ${timeAgo(m.updated_at)}`}</span>
              <a className="btn small" href={`tel:${tel(m.phone)}`}>Call</a>
              <button className="btn small danger" onClick={() => c.del(`/emergency-contacts/${m.contact_id}`, "Remove this contact?", "Contact removed")}>Remove</button></span>
          </div>))}
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ Shelters + services */
export function ResourcesView({ c }) {
  const { shelters, services } = c.d;
  return (
    <>
      <Head title="Shelters & services" sub="Nearest first.">{c.isAdmin && <button className="btn primary" onClick={() => c.modal("shelter")}>Add shelter</button>}</Head>
      <div className="grid2">
        {[...shelters].sort((a, b) => (dist(c, a) ?? 1e9) - (dist(c, b) ?? 1e9)).map((s) => {
          const pct = s.capacity ? Math.round((s.available_slots / s.capacity) * 100) : 0;
          const dd = dist(c, s);
          return (
            <article className="card" key={s.shelter_id}>
              <h3>{s.shelter_name}</h3>
              <p className="muted">{s.location}{dd != null && ` · ${kmText(dd)}`}</p>
              <div className={`bar ${pct < 15 ? "low" : ""}`}><div style={{ width: `${pct}%` }} /></div>
              <p>{s.available_slots} of {s.capacity} slots free</p>
              <div className="btn-row">
                {s.latitude != null && <a className="btn small" href={dirUrl(s.latitude, s.longitude)} target="_blank" rel="noreferrer">Directions</a>}
                {s.contact && <a className="btn small" href={`tel:${tel(s.contact)}`}>Call</a>}
                {c.isAdmin && <button className="btn small" onClick={() => c.setSlots(s)}>Update slots</button>}
                {c.isAdmin && <button className="btn small danger" onClick={() => c.del(`/shelters/${s.shelter_id}`, "Delete this shelter?", "Shelter deleted")}>Delete</button>}
              </div>
            </article>);
        })}
      </div>
      <h3 className="sub">Emergency services</h3>
      <div className="grid2">
        {services.map((s) => (
          <article className="card" key={s.service_id}>
            <h3>{s.service_name}</h3>
            <p className="muted">{s.service_type}{s.availability && ` · ${s.availability}`}{dist(c, s) != null && ` · ${kmText(dist(c, s))}`}</p>
            <div className="btn-row">{s.phone && <a className="btn small primary" href={`tel:${tel(s.phone)}`}>Call {s.phone}</a>}
              {s.latitude != null && <a className="btn small" href={dirUrl(s.latitude, s.longitude)} target="_blank" rel="noreferrer">Directions</a>}</div>
          </article>))}
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ RESPONSE TEAM: Command Center */
const Incident = ({ c, i, actions }) => (
  <article className={`card sev-${(i.severity || "medium").toLowerCase()}`}>
    <div className="card-top">
      <div><h3>{i.is_sos && <span className="tag sos">SOS </span>}{i.incident_type}</h3><p className="muted">{i.location || "No location"} · by {i.reporter_name} · {timeAgo(i.created_at)}{dist(c, i) != null && ` · ${kmText(dist(c, i))}`}</p></div>
      <span className="btn-row"><Badge level={i.severity || "Medium"} /><Badge level={i.status === "Resolved" ? "Low" : i.status === "Pending" ? "Medium" : "High"}>{statusText(i.status)}</Badge></span>
    </div>
    {i.description && <p>{i.description}</p>}
    <div className="card-foot"><span className="muted">{i.people_affected != null ? `${i.people_affected} people affected` : "People affected unknown"}</span>{actions}</div>
  </article>
);
const setStatus = (c, i, status, ok) => c.run(() => api.patch(`/incidents/${i.incident_id}/status`, { status }), ok);

export function CommandCenter({ c }) {
  const { d } = c;
  const open = d.helps.filter(isOpen);
  const assigned = new Set(d.responses.filter((r) => r.status !== "Declined").map((r) => r.request_id));
  const queue = [...open].sort((a, b) => Number(assigned.has(a.request_id)) - Number(assigned.has(b.request_id)) || byPriority(a, b)).slice(0, 6);
  const pending = d.incidents.filter((i) => i.status === "Pending");
  return (
    <>
      <Head title="Command Center" sub="Reports come in, get verified, get assigned, and get a response." />
      <div className="tiles">
        <button className="tile hot" onClick={() => c.setTab("assign")}><b>{open.filter((r) => r.priority === "Critical").length}</b><span>critical requests open</span></button>
        <button className="tile" onClick={() => c.setTab("verify")}><b>{pending.length}</b><span>reports to verify</span></button>
        <button className="tile" onClick={() => c.setTab("assign")}><b>{open.filter((r) => !assigned.has(r.request_id)).length}</b><span>unassigned requests</span></button>
        <button className="tile" onClick={() => c.setTab("map")}><b>{d.volunteers.filter((v) => v.available).length}</b><span>volunteers available</span></button>
      </div>
      <h3 className="sub">Priority queue</h3>
      {queue.length === 0 ? <Empty>Nothing waiting.</Empty> : queue.map((r) => (
        <div className={`card row-card pri-${r.priority.toLowerCase()}`} key={r.request_id}>
          <div><b>{r.request_type}</b> <Badge level={r.priority} /> <span className="muted">{r.requester_name} · {r.location} · {timeAgo(r.created_at)}</span></div>
          {assigned.has(r.request_id) ? <span className="tag">Assigned</span> : <button className="btn small primary" onClick={() => c.modal("assign", r)}>Assign</button>}
        </div>))}
      <h3 className="sub">Newest reports</h3>
      {d.incidents.slice(0, 3).map((i) => <Incident key={i.incident_id} c={c} i={i} />)}
    </>
  );
}

export function ReportsView({ c }) {
  return (
    <>
      <Head title="Reports" sub="Every incident reported by the community." />
      {c.d.incidents.length === 0 ? <Empty>No reports yet.</Empty> : c.d.incidents.map((i) => (
        <Incident key={i.incident_id} c={c} i={i} actions={
          <select className="inline" value={i.status} aria-label="Status" onChange={(e) => setStatus(c, i, e.target.value, "Status updated")}>
            {["Pending", "Verified", "In Progress", "Resolved"].map((s) => <option key={s}>{s}</option>)}
          </select>} />))}
    </>
  );
}

export function VerifyView({ c }) {
  const list = c.d.incidents.filter((i) => i.status === "Pending");
  return (
    <>
      <Head title="Verify" sub="Confirm reports before they drive a response." />
      {list.length === 0 ? <Empty>Everything has been reviewed.</Empty> : list.map((i) => (
        <Incident key={i.incident_id} c={c} i={i} actions={
          <span className="btn-row">
            <button className="btn small primary" onClick={() => setStatus(c, i, "Verified", "Report verified")}>Verify</button>
            <button className="btn small" onClick={() => setStatus(c, i, "In Progress", "Response started")}>Start response</button>
            <button className="btn small danger" onClick={() => setStatus(c, i, "Resolved", "Closed")}>Close</button>
          </span>} />))}
    </>
  );
}

export function AssignView({ c }) {
  const list = c.d.helps.filter(isOpen).sort(byPriority);
  return (
    <>
      <Head title="Assign" sub="Pick a volunteer. Best matches are ranked by skills, resources and distance." />
      {list.length === 0 ? <Empty>No open requests.</Empty> : list.map((r) => {
        const who = c.d.responses.filter((x) => x.request_id === r.request_id && x.status !== "Declined");
        return (
          <article className={`card pri-${r.priority.toLowerCase()}`} key={r.request_id}>
            <div className="card-top"><div><h3>{r.request_type}</h3><p className="muted">{r.requester_name} · {r.location} · {timeAgo(r.created_at)}</p></div><Badge level={r.priority} /></div>
            {r.description && <p>{r.description}</p>}
            <div className="card-foot">
              <span className="muted">{who.length ? `Assigned: ${who.map((x) => `${x.volunteer_name} (${x.status})`).join(", ")}` : "No one assigned"}</span>
              <button className="btn small primary" onClick={() => c.modal("assign", r)}>{who.length ? "Add another" : "Assign volunteer"}</button>
            </div>
          </article>);
      })}
    </>
  );
}

export function ResponseView({ c }) {
  return (
    <>
      <Head title="Response" sub="What volunteers are doing about each request." />
      {c.d.responses.length === 0 ? <Empty>No responses yet.</Empty> : c.d.responses.map((r) => (
        <div className="card row-card" key={r.response_id}>
          <div><b>{r.volunteer_name}</b> <span className="muted">on {r.request_type}. {r.message}</span></div>
          <span className="btn-row"><Badge level={r.status === "Completed" ? "Low" : r.status === "Declined" ? "Critical" : "High"}>{r.status}</Badge>
            {["Assigned", "Accepted"].includes(r.status) && <button className="btn small" onClick={() => c.run(() => api.patch(`/community-responses/${r.response_id}/status`, { status: "Completed" }), "Marked completed")}>Complete</button>}</span>
        </div>))}
    </>
  );
}

/* ------------------------------------------------------------------ Assign modal body */
export function useMatches(requestId) {
  const [m, setM] = useState(null);
  useEffect(() => { api.get(`/help-requests/${requestId}/matches`).then(setM).catch(() => setM([])); }, [requestId]);
  return m;
}
