import { useState } from "react";

export const HELP_TYPES = ["Medical Help", "Food", "Rescue", "Shelter", "Water"];
export const INCIDENT_TYPES = ["Flood", "Fire", "Earthquake", "Landslide", "Cyclone", "Accident", "Medical Emergency"];
export const SOS_TYPES = ["Medical emergency", "Trapped", "Fire", "Flood", "Accident", "Missing person", "Other"];
export const SKILLS = ["First Aid", "Driving", "Rescue", "Medical"];
export const PRIORITIES = [
  ["Critical", "Life-threatening / trapped"],
  ["High", "Urgent medical or evacuation assistance"],
  ["Medium", "Food, water, shelter"],
  ["Low", "General assistance"],
];
export const PRIORITY_RANK = { Critical: 0, High: 1, Medium: 2, Low: 3 };
export const DEFAULT_POS = { lat: 17.385, lng: 78.4867, live: false };   // Hyderabad, used when GPS is off

export function timeAgo(iso) {
  if (!iso) return "";
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return "just now";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} hr ago`;
  return `${Math.floor(h / 24)} day${Math.floor(h / 24) === 1 ? "" : "s"} ago`;
}

export function km(a, b, c, d) {
  if ([a, b, c, d].some((v) => v == null)) return null;
  const r = (x) => (x * Math.PI) / 180;
  const h = Math.sin(r(c - a) / 2) ** 2 + Math.cos(r(a)) * Math.cos(r(c)) * Math.sin(r(d - b) / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.sqrt(h));
}
export const kmText = (v) => (v == null ? "" : v < 1 ? `${Math.round(v * 1000)} m away` : `${v.toFixed(1)} km away`);
export const dirUrl = (lat, lng) => `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
export const tel = (p) => (p ? String(p).replace(/\s/g, "") : "");
export const statusText = (s) =>
  ({ Pending: "Awaiting verification", Verified: "Verified", "In Progress": "Response in progress", Resolved: "Resolved" }[s] || s);

export const Badge = ({ level, children }) => (
  <span className={`badge b-${String(level).toLowerCase().replace(" ", "-")}`}>{children ?? level}</span>
);
export const Empty = ({ children }) => <div className="empty">{children}</div>;
export const F = ({ label, children }) => (<label className="field"><span>{label}</span>{children}</label>);
export const Opts = ({ list }) => list.map((t) => <option key={t}>{t}</option>);

export function FormModal({ onClose, onSubmit, submitLabel, title, subtitle, children }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const handle = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try { await onSubmit(new FormData(e.currentTarget)); }
    catch (err) { setError(err.message); setBusy(false); }
  };
  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-label={title}>
        <button className="modal-x" onClick={onClose} type="button" aria-label="Close">×</button>
        <h2>{title}</h2>
        {subtitle && <p className="muted">{subtitle}</p>}
        <form onSubmit={handle}>
          {children}
          {error && <div className="form-error">{error}</div>}
          <div className="modal-actions">
            <button className="btn" onClick={onClose} type="button">Cancel</button>
            <button className="btn primary" disabled={busy} type="submit">{busy ? "Please wait…" : submitLabel}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
