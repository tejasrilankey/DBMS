// Small helper for talking to the FastAPI backend.
//
// By default it calls the backend on the same machine/hostname the page was opened
// from, port 8000 - so both http://localhost:5173 and http://127.0.0.1:5173 work.
// To point somewhere else, create frontend/.env with:  VITE_API_URL=http://your-server:8000
const API_URL = (
  import.meta.env.VITE_API_URL || `http://${window.location.hostname}:8000`
).replace(/\/$/, "");

const TOKEN_KEY = "safesphere_token";

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (token) =>
  token ? localStorage.setItem(TOKEN_KEY, token) : localStorage.removeItem(TOKEN_KEY);

async function request(path, { method = "GET", body, form } = {}) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  let payload;
  if (form) {
    headers["Content-Type"] = "application/x-www-form-urlencoded";
    payload = new URLSearchParams(form);
  } else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }

  let res;
  try {
    res = await fetch(`${API_URL}${path}`, { method, headers, body: payload });
  } catch {
    throw new Error(
      `Cannot reach the server at ${API_URL}. Is the backend running? (run_backend.bat / run_backend.sh)`
    );
  }

  if (res.status === 204) return null;

  let data = null;
  try {
    data = await res.json();
  } catch {
    /* response had no JSON body */
  }

  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    if (typeof data?.detail === "string") message = data.detail;
    else if (Array.isArray(data?.detail))
      message = data.detail
        .map((d) => `${(d.loc || []).slice(1).join(".")}: ${d.msg}`)
        .join(", ");
    const err = new Error(message);
    err.status = res.status;
    throw err;
  }
  return data;
}

export const api = {
  get: (path) => request(path),
  post: (path, body) => request(path, { method: "POST", body }),
  put: (path, body) => request(path, { method: "PUT", body }),
  patch: (path, body) => request(path, { method: "PATCH", body }),
  del: (path) => request(path, { method: "DELETE" }),
  login: (email, password) =>
    request("/auth/login", { method: "POST", form: { username: email, password } }),
  register: (data) => request("/auth/register", { method: "POST", body: data }),
};
