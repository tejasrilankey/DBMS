# SafeSphere

Vite + React frontend (`npm run dev`). See the project root README for how to run everything.
