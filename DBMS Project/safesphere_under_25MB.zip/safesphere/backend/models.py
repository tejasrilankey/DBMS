"""MongoDB collections (there are no table classes any more - documents are plain dicts).

Core collections (from the ER diagram):
  users(user_id) disaster_alerts(disaster_id) shelters(shelter_id) emergency_contacts(contact_id)
  emergency_services(service_id) incident_reports(incident_id) help_requests(request_id)
  community_responses(response_id)
Supporting collections:
  user_locations(user_id) volunteer_profiles(user_id) safety_checkins(checkin_id) notifications(notification_id)
  counters  (internal: auto-increment ids)

Differences from the SQL version:
  * foreign keys are just stored ids (user_id, request_id ...); cascades are done in the routes
  * reporter_name / requester_name / volunteer_name / request_type are stored inside the document
  * volunteer_profiles.skills and .resources are real arrays (no JSON text)
"""
from datetime import datetime, timezone
from types import SimpleNamespace

from pymongo import DESCENDING
from pymongo.database import Database


def utcnow() -> datetime:
    """Naive UTC timestamp (MongoDB stores datetimes as UTC)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(SimpleNamespace):
    """The logged-in user, built from a users document (user.user_id, user.name, user.role ...)."""


def ensure_indexes(db: Database) -> None:
    db.users.create_index("user_id", unique=True)
    db.users.create_index("email", unique=True)
    db.disaster_alerts.create_index("disaster_id", unique=True)
    db.shelters.create_index("shelter_id", unique=True)
    db.emergency_contacts.create_index("contact_id", unique=True)
    db.emergency_contacts.create_index("user_id")
    db.emergency_services.create_index("service_id", unique=True)
    db.incident_reports.create_index("incident_id", unique=True)
    db.help_requests.create_index("request_id", unique=True)
    db.community_responses.create_index("response_id", unique=True)
    db.community_responses.create_index([("request_id", 1), ("volunteer_id", 1)], unique=True)  # one reply per volunteer
    db.user_locations.create_index("user_id", unique=True)
    db.volunteer_profiles.create_index("user_id", unique=True)
    db.safety_checkins.create_index("checkin_id", unique=True)
    db.safety_checkins.create_index([("user_id", 1), ("checkin_id", DESCENDING)])
    db.notifications.create_index("notification_id", unique=True)
    db.notifications.create_index([("user_id", 1), ("notification_id", DESCENDING)])
