"""Pydantic schemas = the JSON shapes the API accepts and returns."""
from datetime import datetime, timezone
from typing import Annotated, Literal, Optional
from pydantic import BaseModel, ConfigDict, EmailStr, Field, PlainSerializer


def _utc(value: datetime) -> str:
    # DB stores naive UTC; send it with a "Z" so browsers convert to local time correctly
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.isoformat().replace("+00:00", "Z")


UTCDateTime = Annotated[datetime, PlainSerializer(_utc, return_type=str)]

Lat = Annotated[Optional[float], Field(default=None, ge=-90, le=90)]
Lng = Annotated[Optional[float], Field(default=None, ge=-180, le=180)]

Severity = Literal["Low", "Medium", "High", "Critical"]
Priority = Literal["Critical", "High", "Medium", "Low"]
SOS_TYPES = Literal["Medical emergency", "Trapped", "Fire", "Flood", "Accident", "Missing person", "Other"]
SKILLS = Literal["First Aid", "Driving", "Rescue", "Medical"]


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---------- Auth / Users ----------
class UserCreate(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    phone: Optional[str] = Field(default=None, max_length=15)
    password: str = Field(min_length=6, max_length=72)
    role: Literal["citizen", "volunteer"] = "citizen"   # 'admin' can only be set in the database


class UserOut(ORM):
    user_id: int
    name: str
    email: str
    phone: Optional[str] = None
    role: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class LocationIn(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)


# ---------- Disaster alerts ----------
class AlertCreate(BaseModel):
    disaster_type: str = Field(max_length=50)
    title: str = Field(max_length=150)
    description: Optional[str] = None
    severity: Severity
    location: str = Field(max_length=150)
    latitude: Lat
    longitude: Lng
    radius_km: Optional[float] = Field(default=None, gt=0, le=2000)
    safety_instructions: Optional[str] = None
    evacuation_info: Optional[str] = None
    source: Optional[str] = Field(default=None, max_length=100)
    verified: bool = True


class AlertOut(ORM, AlertCreate):
    disaster_id: int
    alert_time: UTCDateTime


# ---------- Shelters ----------
class ShelterCreate(BaseModel):
    shelter_name: str = Field(max_length=150)
    location: str = Field(max_length=150)
    capacity: int = Field(ge=0)
    available_slots: int = Field(ge=0)
    contact: Optional[str] = Field(default=None, max_length=15)
    latitude: Lat
    longitude: Lng


class ShelterOut(ORM, ShelterCreate):
    shelter_id: int


class ShelterSlotsUpdate(BaseModel):
    available_slots: int = Field(ge=0)


# ---------- Emergency services ----------
class ServiceCreate(BaseModel):
    service_name: str = Field(max_length=100)
    service_type: str = Field(max_length=50)
    location: Optional[str] = Field(default=None, max_length=150)
    phone: Optional[str] = Field(default=None, max_length=15)
    availability: Optional[str] = Field(default=None, max_length=30)
    shelter_id: Optional[int] = None
    latitude: Lat
    longitude: Lng


class ServiceOut(ORM):
    service_id: int
    service_name: str
    service_type: str
    location: Optional[str] = None
    phone: Optional[str] = None
    availability: Optional[str] = None
    shelter_id: Optional[int] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None


# ---------- Emergency contacts ----------
class ContactCreate(BaseModel):
    contact_name: str = Field(max_length=100)
    relationship: Optional[str] = Field(default=None, max_length=50)
    phone: str = Field(max_length=15)


class ContactOut(ORM):
    contact_id: int
    contact_name: str
    relationship: Optional[str] = None
    phone: str


# ---------- Incident reports ----------
class IncidentCreate(BaseModel):
    incident_type: str = Field(max_length=50)
    description: Optional[str] = None
    location: Optional[str] = Field(default=None, max_length=150)
    disaster_id: Optional[int] = None
    latitude: Lat
    longitude: Lng
    severity: Literal["Low", "Medium", "High", "Critical"] = "Medium"
    people_affected: Optional[int] = Field(default=None, ge=0, le=100000)


class IncidentStatusUpdate(BaseModel):
    status: Literal["Pending", "Verified", "In Progress", "Resolved"]


class IncidentOut(ORM):
    incident_id: int
    user_id: int
    disaster_id: Optional[int] = None
    incident_type: str
    description: Optional[str] = None
    location: Optional[str] = None
    status: str
    reporter_name: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    severity: Optional[str] = None
    people_affected: Optional[int] = None
    created_at: Optional[UTCDateTime] = None
    is_sos: Optional[bool] = False


# ---------- Help requests ----------
class HelpCreate(BaseModel):
    request_type: str = Field(max_length=50)
    description: Optional[str] = None
    location: Optional[str] = Field(default=None, max_length=150)
    priority: Priority = "Medium"
    latitude: Lat
    longitude: Lng


class HelpStatusUpdate(BaseModel):
    status: Literal["Pending", "Accepted", "Completed", "Cancelled"]


class HelpOut(ORM):
    request_id: int
    user_id: int
    request_type: str
    description: Optional[str] = None
    location: Optional[str] = None
    priority: str
    status: str
    requester_name: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    created_at: Optional[UTCDateTime] = None


# ---------- Community responses ----------
class ResponseCreate(BaseModel):
    request_id: int
    response_type: Optional[str] = Field(default="Assistance", max_length=50)
    message: Optional[str] = None
    disaster_id: Optional[int] = None
    shelter_id: Optional[int] = None


class ResponseOut(ORM):
    response_id: int
    request_id: int
    volunteer_id: int
    response_type: Optional[str] = None
    message: Optional[str] = None
    status: str
    volunteer_name: Optional[str] = None
    request_type: Optional[str] = None


class ResponseStatusUpdate(BaseModel):
    status: Literal["Accepted", "Declined", "Completed"]


class AssignIn(BaseModel):
    volunteer_id: int
    message: Optional[str] = None


class Stats(BaseModel):
    alerts: int
    incidents: int
    help_requests: int
    shelters: int
    volunteers_responses: int


# ---------- SOS ----------
class SOSCreate(BaseModel):
    sos_type: SOS_TYPES
    latitude: Lat
    longitude: Lng
    location: Optional[str] = Field(default=None, max_length=150)
    description: Optional[str] = Field(default=None, max_length=1000)
    people_affected: Optional[int] = Field(default=None, ge=1, le=100000)


class SOSContact(BaseModel):
    contact_name: str
    relationship: Optional[str] = None
    phone: str
    in_app: bool = False          # True = also got an in-app notification


class NearbyPlace(BaseModel):
    id: int
    name: str
    location: Optional[str] = None
    phone: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    distance_km: Optional[float] = None


class SOSOut(BaseModel):
    incident_id: int
    request_id: int
    priority: str
    contacts: list[SOSContact]
    notified_response_team: int
    notified_volunteers: int
    nearby_shelters: list[NearbyPlace]
    nearby_hospitals: list[NearbyPlace]


# ---------- Live map ----------
class MapVolunteer(BaseModel):
    user_id: int
    name: str
    skills: list[str]
    latitude: float
    longitude: float


class MapOut(BaseModel):
    alerts: list[AlertOut]
    incidents: list[IncidentOut]
    shelters: list[ShelterOut]
    hospitals: list[ServiceOut]
    services: list[ServiceOut]
    volunteers: list[MapVolunteer]


# ---------- Volunteers ----------
class VolunteerProfileIn(BaseModel):
    skills: list[SKILLS] = []
    resources: list[Annotated[str, Field(min_length=1, max_length=40)]] = Field(default=[], max_length=12)
    location: Optional[str] = Field(default=None, max_length=150)
    available: bool = True


class VolunteerProfileOut(BaseModel):
    user_id: int
    name: str
    phone: Optional[str] = None
    skills: list[str] = []
    resources: list[str] = []
    location: Optional[str] = None
    available: bool = False
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    distance_km: Optional[float] = None


class VolunteerMatch(VolunteerProfileOut):
    score: int = 0
    reasons: list[str] = []


# ---------- Family safety check-in ----------
class CheckinCreate(BaseModel):
    status: Literal["Safe", "Needs help"]
    note: Optional[str] = Field(default=None, max_length=300)
    share_with_contacts: bool = True     # explicit consent; nothing is shared when False


class CheckinOut(ORM):
    checkin_id: int
    status: str
    note: Optional[str] = None
    shared: bool
    created_at: UTCDateTime
    notified: int = 0


class FamilyMember(BaseModel):
    contact_id: int
    contact_name: str
    relationship: Optional[str] = None
    phone: str
    status: Literal["Safe", "Needs help", "No update"]
    updated_at: Optional[UTCDateTime] = None
    on_safesphere: bool = False


# ---------- Notifications ----------
class NotificationOut(ORM):
    notification_id: int
    title: str
    message: Optional[str] = None
    kind: str
    level: str
    is_read: bool
    created_at: UTCDateTime
