"""Routes that need a logged-in user: incidents, help requests, responses, personal contacts."""
from fastapi import APIRouter, Depends, HTTPException, status
from pymongo import ReturnDocument
from pymongo.database import Database
from pymongo.errors import DuplicateKeyError

from database import NO_ID, get_db, insert
from models import User, utcnow
from schemas import (ContactCreate, ContactOut, HelpCreate, HelpOut,
                     HelpStatusUpdate, IncidentCreate, IncidentOut,
                     IncidentStatusUpdate, ResponseCreate, ResponseOut)
from security import get_current_user, require_admin, require_responder
from services import admin_ids, notify

router = APIRouter()


# ---------- Incident reports ----------
@router.get("/incidents", response_model=list[IncidentOut], tags=["Incident Reports"])
def list_incidents(db: Database = Depends(get_db), _: User = Depends(get_current_user)):
    return list(db.incident_reports.find({}, NO_ID).sort("incident_id", -1))


@router.post("/incidents", response_model=IncidentOut, status_code=201, tags=["Incident Reports"])
def create_incident(data: IncidentCreate, db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    if data.disaster_id is not None and not db.disaster_alerts.find_one({"disaster_id": data.disaster_id}):
        raise HTTPException(400, "disaster_id does not exist")
    incident = insert(db, "incident_reports", "incident_id", {
        **data.model_dump(), "user_id": user.user_id, "status": "Pending", "is_sos": False,
        "created_at": utcnow(), "reporter_name": user.name})
    notify(db, admin_ids(db), f"New incident: {data.incident_type}",
           f"{user.name} reported {data.incident_type} at {data.location or 'unknown location'}. Verify it in the Command Center.",
           kind="incident", level="warning")
    return incident


@router.patch("/incidents/{incident_id}/status", response_model=IncidentOut, tags=["Incident Reports"],
              dependencies=[Depends(require_admin)])
def update_incident_status(incident_id: int, data: IncidentStatusUpdate, db: Database = Depends(get_db)):
    incident = db.incident_reports.find_one_and_update(
        {"incident_id": incident_id}, {"$set": {"status": data.status}},
        projection=NO_ID, return_document=ReturnDocument.AFTER)
    if not incident:
        raise HTTPException(404, "Incident not found")
    return incident


# ---------- Help requests ----------
@router.get("/help-requests", response_model=list[HelpOut], tags=["Help Requests"])
def list_help_requests(db: Database = Depends(get_db), _: User = Depends(get_current_user)):
    return list(db.help_requests.find({}, NO_ID).sort("request_id", -1))


@router.post("/help-requests", response_model=HelpOut, status_code=201, tags=["Help Requests"])
def create_help_request(data: HelpCreate, db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    req = insert(db, "help_requests", "request_id", {
        **data.model_dump(), "user_id": user.user_id, "status": "Pending",
        "created_at": utcnow(), "requester_name": user.name})
    notify(db, admin_ids(db), f"{data.priority} help request: {data.request_type}",
           f"{user.name} at {data.location or 'unknown location'}.", kind="help",
           level="critical" if data.priority == "Critical" else "warning")
    return req


@router.patch("/help-requests/{request_id}/status", response_model=HelpOut, tags=["Help Requests"])
def update_help_status(request_id: int, data: HelpStatusUpdate, db: Database = Depends(get_db),
                       user: User = Depends(get_current_user)):
    req = db.help_requests.find_one({"request_id": request_id}, NO_ID)
    if not req:
        raise HTTPException(404, "Help request not found")
    is_responder = db.community_responses.find_one(
        {"request_id": request_id, "volunteer_id": user.user_id}) is not None
    if req["user_id"] != user.user_id and user.role != "admin" and not is_responder:
        raise HTTPException(403, "Only the requester, a responding volunteer or an admin can update this request")
    db.help_requests.update_one({"request_id": request_id}, {"$set": {"status": data.status}})
    req["status"] = data.status
    return req


# ---------- Community responses ----------
@router.get("/community-responses", response_model=list[ResponseOut], tags=["Community Responses"])
def list_responses(db: Database = Depends(get_db), _: User = Depends(get_current_user)):
    return list(db.community_responses.find({}, NO_ID).sort("response_id", -1))


@router.post("/community-responses", response_model=ResponseOut, status_code=201, tags=["Community Responses"])
def create_response(data: ResponseCreate, db: Database = Depends(get_db),
                    volunteer: User = Depends(require_responder)):
    req = db.help_requests.find_one({"request_id": data.request_id}, NO_ID)
    if not req:
        raise HTTPException(404, "Help request not found")
    if req["user_id"] == volunteer.user_id:
        raise HTTPException(400, "You cannot respond to your own request")
    if req["status"] in ("Completed", "Cancelled"):
        raise HTTPException(400, f"This request is already {req['status'].lower()}")
    if data.disaster_id is not None and not db.disaster_alerts.find_one({"disaster_id": data.disaster_id}):
        raise HTTPException(400, "disaster_id does not exist")
    if data.shelter_id is not None and not db.shelters.find_one({"shelter_id": data.shelter_id}):
        raise HTTPException(400, "shelter_id does not exist")
    if db.community_responses.find_one({"request_id": data.request_id, "volunteer_id": volunteer.user_id}):
        raise HTTPException(400, "You have already responded to this request")
    try:
        response = insert(db, "community_responses", "response_id", {
            **data.model_dump(), "volunteer_id": volunteer.user_id, "status": "Accepted",
            "volunteer_name": volunteer.name, "request_type": req["request_type"]})
    except DuplicateKeyError:
        raise HTTPException(400, "You have already responded to this request")
    if req["status"] == "Pending":
        db.help_requests.update_one({"request_id": data.request_id}, {"$set": {"status": "Accepted"}})
    return response


# ---------- Personal emergency contacts (each user sees only their own) ----------
@router.get("/emergency-contacts", response_model=list[ContactOut], tags=["Emergency Contacts"])
def list_contacts(db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    return list(db.emergency_contacts.find({"user_id": user.user_id}, NO_ID).sort("contact_id", 1))


@router.post("/emergency-contacts", response_model=ContactOut, status_code=201, tags=["Emergency Contacts"])
def create_contact(data: ContactCreate, db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    return insert(db, "emergency_contacts", "contact_id", dict(
        user_id=user.user_id, contact_name=data.contact_name, relationship=data.relationship, phone=data.phone))


@router.delete("/emergency-contacts/{contact_id}", status_code=status.HTTP_204_NO_CONTENT,
               tags=["Emergency Contacts"])
def delete_contact(contact_id: int, db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    if db.emergency_contacts.delete_one({"contact_id": contact_id, "user_id": user.user_id}).deleted_count == 0:
        raise HTTPException(404, "Contact not found")
    db.emergency_services.update_many({"contact_id": contact_id}, {"$set": {"contact_id": None}})  # SET NULL
