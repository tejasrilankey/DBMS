"""End-to-end API test.  Run from the backend folder:   python -m pytest -q
Uses a throw-away SQLite file, never your real database."""
import os
import sys
import tempfile
from pathlib import Path

_tmp = Path(tempfile.mkdtemp()) / "test.db"
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}"
os.environ["SEED_DEMO"] = "true"
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from main import app  # noqa: E402


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:      # runs startup -> creates tables + seeds
        yield c


def login(client, email, password):
    r = client.post("/auth/login", data={"username": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def test_health_and_public_data(client):
    assert client.get("/").json()["status"] == "ok"
    alerts = client.get("/disaster-alerts").json()
    assert len(alerts) == 3 and alerts[0]["alert_time"].endswith("Z")
    assert alerts[0]["title"] == "Flood Warning"          # newest first
    assert len(client.get("/shelters").json()) == 2
    assert len(client.get("/emergency-services").json()) == 4
    s = client.get("/stats").json()
    assert s["alerts"] == 3 and s["shelters"] == 2 and s["incidents"] == 2


def test_protected_routes_need_login(client):
    for path in ("/incidents", "/help-requests", "/community-responses", "/emergency-contacts", "/auth/me"):
        assert client.get(path).status_code == 401
    assert client.post("/disaster-alerts", json={}).status_code == 401


def test_register_login_me(client):
    body = {"name": "Test User", "email": "Test@Example.com", "password": "secret1", "role": "citizen"}
    r = client.post("/auth/register", json=body)
    assert r.status_code == 201 and r.json()["user"]["email"] == "test@example.com"
    assert client.post("/auth/register", json=body).status_code == 400            # duplicate
    assert client.post("/auth/register", json={**body, "email": "x@y.com", "role": "admin"}).status_code == 422
    assert client.post("/auth/login", data={"username": "test@example.com", "password": "wrong"}).status_code == 401
    h = login(client, "TEST@example.com", "secret1")                               # case-insensitive
    assert client.get("/auth/me", headers=h).json()["name"] == "Test User"
    assert client.get("/auth/me", headers={"Authorization": "Bearer garbage"}).status_code == 401


def test_admin_only_writes(client):
    citizen = login(client, "citizen@safesphere.com", "citizen123")
    admin = login(client, "admin@safesphere.com", "admin123")
    alert = {"disaster_type": "Fire", "title": "Wildfire", "severity": "High", "location": "Hills", "description": "x"}
    assert client.post("/disaster-alerts", json=alert, headers=citizen).status_code == 403
    r = client.post("/disaster-alerts", json=alert, headers=admin)
    assert r.status_code == 201
    assert client.get("/disaster-alerts").json()[0]["title"] == "Wildfire"
    assert client.delete(f"/disaster-alerts/{r.json()['disaster_id']}", headers=citizen).status_code == 403
    assert client.delete(f"/disaster-alerts/{r.json()['disaster_id']}", headers=admin).status_code == 204
    assert client.delete("/disaster-alerts/9999", headers=admin).status_code == 404
    assert client.post("/disaster-alerts", json={**alert, "severity": "Extreme"}, headers=admin).status_code == 422

    sh = {"shelter_name": "Stadium", "location": "Centre", "capacity": 100, "available_slots": 100, "contact": "123"}
    assert client.post("/shelters", json={**sh, "available_slots": 101}, headers=admin).status_code == 400
    sid = client.post("/shelters", json=sh, headers=admin).json()["shelter_id"]
    assert client.patch(f"/shelters/{sid}/slots", json={"available_slots": 40}, headers=admin).json()["available_slots"] == 40
    assert client.patch(f"/shelters/{sid}/slots", json={"available_slots": 400}, headers=admin).status_code == 400
    svc = client.post("/emergency-services", json={"service_name": "Ambulance", "service_type": "Medical",
                                                   "phone": "102", "shelter_id": sid}, headers=admin)
    assert svc.status_code == 201
    assert client.post("/emergency-services", json={"service_name": "x", "service_type": "y",
                                                    "shelter_id": 9999}, headers=admin).status_code == 400
    assert client.delete(f"/shelters/{sid}", headers=admin).status_code == 204     # service keeps existing
    assert any(s["service_id"] == svc.json()["service_id"] for s in client.get("/emergency-services").json())
    assert client.delete(f"/emergency-services/{svc.json()['service_id']}", headers=admin).status_code == 204


def test_incident_flow(client):
    citizen = login(client, "citizen@safesphere.com", "citizen123")
    admin = login(client, "admin@safesphere.com", "admin123")
    r = client.post("/incidents", json={"incident_type": "Landslide", "location": "Hill road",
                                        "description": "Blocked"}, headers=citizen)
    assert r.status_code == 201 and r.json()["reporter_name"] == "Priya" and r.json()["status"] == "Pending"
    iid = r.json()["incident_id"]
    assert client.post("/incidents", json={"incident_type": "Flood", "disaster_id": 9999}, headers=citizen).status_code == 400
    assert any(i["incident_id"] == iid for i in client.get("/incidents", headers=citizen).json())
    assert client.patch(f"/incidents/{iid}/status", json={"status": "Verified"}, headers=citizen).status_code == 403
    r = client.patch(f"/incidents/{iid}/status", json={"status": "Verified"}, headers=admin)
    assert r.status_code == 200 and r.json()["status"] == "Verified"
    assert client.patch(f"/incidents/{iid}/status", json={"status": "Bogus"}, headers=admin).status_code == 422


def test_help_and_community_response_flow(client):
    citizen = login(client, "citizen@safesphere.com", "citizen123")
    other = login(client, "arjun@example.com", "citizen123")
    volunteer = login(client, "volunteer@safesphere.com", "volunteer123")

    r = client.post("/help-requests", json={"request_type": "Water", "priority": "High", "location": "Zone 9",
                                            "description": "No drinking water"}, headers=citizen)
    assert r.status_code == 201 and r.json()["requester_name"] == "Priya"
    rid = r.json()["request_id"]

    # a plain citizen may not respond; nobody may respond to their own request
    assert client.post("/community-responses", json={"request_id": rid}, headers=other).status_code == 403
    assert client.post("/community-responses", json={"request_id": 9999}, headers=volunteer).status_code == 404

    r = client.post("/community-responses", json={"request_id": rid, "message": "Bringing water"}, headers=volunteer)
    assert r.status_code == 201
    assert r.json()["volunteer_name"] == "Rahul" and r.json()["request_type"] == "Water"
    assert client.post("/community-responses", json={"request_id": rid}, headers=volunteer).status_code == 400  # duplicate
    req = next(x for x in client.get("/help-requests", headers=citizen).json() if x["request_id"] == rid)
    assert req["status"] == "Accepted"                                        # auto-accepted

    assert client.patch(f"/help-requests/{rid}/status", json={"status": "Completed"}, headers=other).status_code == 403
    assert client.patch(f"/help-requests/{rid}/status", json={"status": "Completed"}, headers=volunteer).status_code == 200
    assert client.post("/community-responses", json={"request_id": rid}, headers=login(
        client, "admin@safesphere.com", "admin123")).status_code == 400        # already completed
    assert len(client.get("/community-responses", headers=citizen).json()) >= 2


def test_personal_contacts_are_private(client):
    a = login(client, "citizen@safesphere.com", "citizen123")
    b = login(client, "arjun@example.com", "citizen123")
    assert len(client.get("/emergency-contacts", headers=a).json()) == 3
    assert len(client.get("/emergency-contacts", headers=b).json()) == 1   # seeded: Priya
    r = client.post("/emergency-contacts", json={"contact_name": "Neighbour", "relationship": "Friend",
                                                 "phone": "555"}, headers=b)
    assert r.status_code == 201 and r.json()["relationship"] == "Friend"
    cid = r.json()["contact_id"]
    assert client.delete(f"/emergency-contacts/{cid}", headers=a).status_code == 404   # not theirs
    assert client.delete(f"/emergency-contacts/{cid}", headers=b).status_code == 204


# ---------------------------------------------------------------- new features
def test_location_based_alerts(client):
    titles = lambda r: {a["title"] for a in r.json()}
    near = titles(client.get("/disaster-alerts", params={"lat": 17.399, "lng": 78.478}))
    assert "Flood Warning" in near and "Cyclone Alert" not in near      # East Coast is far from Hyderabad
    assert "Cyclone Alert" in titles(client.get("/disaster-alerts"))     # no location -> everything


def test_alert_notifies_only_people_in_area(client):
    admin = login(client, "admin@safesphere.com", "admin123")
    citizen = login(client, "citizen@safesphere.com", "citizen123")
    before = len(client.get("/notifications", headers=citizen).json())
    alert = {"disaster_type": "Flood", "title": "Local Flood", "severity": "High", "location": "Sector 12",
             "latitude": 17.40, "longitude": 78.478, "radius_km": 3, "safety_instructions": "Move up."}
    assert client.post("/disaster-alerts", json=alert, headers=admin).status_code == 201
    assert len(client.get("/notifications", headers=citizen).json()) == before + 1
    far = {**alert, "title": "Far Flood", "latitude": 28.6, "longitude": 77.2}
    client.post("/disaster-alerts", json=far, headers=admin)
    assert len(client.get("/notifications", headers=citizen).json()) == before + 1


def test_sos_flow(client):
    citizen = login(client, "citizen@safesphere.com", "citizen123")
    admin = login(client, "admin@safesphere.com", "admin123")
    r = client.post("/sos", json={"sos_type": "Trapped", "latitude": 17.399, "longitude": 78.478}, headers=citizen)
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["priority"] == "Critical" and len(body["contacts"]) == 3
    assert any(c["in_app"] for c in body["contacts"])                    # Arjun is a SafeSphere user
    assert body["notified_response_team"] >= 1 and body["nearby_shelters"][0]["distance_km"] is not None
    reqs = client.get("/help-requests", headers=admin).json()
    assert any(x["request_id"] == body["request_id"] and x["priority"] == "Critical" for x in reqs)
    assert client.post("/sos", json={"sos_type": "Nonsense"}, headers=citizen).status_code == 422


def test_map_and_volunteer_privacy(client):
    citizen = login(client, "citizen@safesphere.com", "citizen123")
    volunteer = login(client, "volunteer@safesphere.com", "volunteer123")
    m = client.get("/map", headers=citizen).json()
    assert m["alerts"] and m["shelters"] and m["hospitals"] and m["volunteers"] == []
    assert len(client.get("/map", headers=volunteer).json()["volunteers"]) == 1
    assert client.get("/map").status_code == 401


def test_volunteer_profile_match_assign(client):
    citizen = login(client, "citizen@safesphere.com", "citizen123")
    volunteer = login(client, "volunteer@safesphere.com", "volunteer123")
    admin = login(client, "admin@safesphere.com", "admin123")
    assert client.put("/volunteers/me", json={"skills": ["Rescue"]}, headers=citizen).status_code == 403
    r = client.put("/volunteers/me", json={"skills": ["Rescue", "Driving"], "resources": ["Car"], "available": True},
                   headers=volunteer)
    assert r.status_code == 200 and r.json()["skills"] == ["Rescue", "Driving"]
    assert client.put("/volunteers/me", json={"skills": ["Cooking"]}, headers=volunteer).status_code == 422
    rid = client.post("/help-requests", json={"request_type": "Rescue", "priority": "Critical", "location": "X",
                                             "latitude": 17.40, "longitude": 78.47}, headers=citizen).json()["request_id"]
    assert client.get(f"/help-requests/{rid}/matches", headers=citizen).status_code == 403
    matches = client.get(f"/help-requests/{rid}/matches", headers=admin).json()
    assert matches and matches[0]["name"] == "Rahul" and matches[0]["score"] > 0
    a = client.post(f"/help-requests/{rid}/assign", json={"volunteer_id": matches[0]["user_id"]}, headers=admin)
    assert a.status_code == 201 and a.json()["status"] == "Assigned"
    assert client.post(f"/help-requests/{rid}/assign", json={"volunteer_id": matches[0]["user_id"]},
                       headers=admin).status_code == 400
    assert client.patch(f"/community-responses/{a.json()['response_id']}/status", json={"status": "Completed"},
                        headers=citizen).status_code == 403
    done = client.patch(f"/community-responses/{a.json()['response_id']}/status", json={"status": "Completed"},
                        headers=volunteer)
    assert done.status_code == 200
    req = next(x for x in client.get("/help-requests", headers=admin).json() if x["request_id"] == rid)
    assert req["status"] == "Completed"


def test_family_checkin_with_consent(client):
    priya = login(client, "citizen@safesphere.com", "citizen123")
    arjun = login(client, "arjun@example.com", "citizen123")
    board = {m["contact_name"]: m for m in client.get("/checkins/family", headers=priya).json()}
    assert board["Arjun"]["status"] == "Needs help" and board["Father"]["status"] == "No update"
    # Arjun checks in but does NOT consent to share -> Priya sees nothing new
    client.post("/checkins", json={"status": "Safe", "share_with_contacts": False}, headers=arjun)
    board = {m["contact_name"]: m for m in client.get("/checkins/family", headers=priya).json()}
    assert board["Arjun"]["status"] == "No update"
    r = client.post("/checkins", json={"status": "Safe"}, headers=arjun)
    assert r.status_code == 201 and r.json()["notified"] == 1
    board = {m["contact_name"]: m for m in client.get("/checkins/family", headers=priya).json()}
    assert board["Arjun"]["status"] == "Safe"


def test_notifications_read(client):
    admin = login(client, "admin@safesphere.com", "admin123")
    assert any(not n["is_read"] for n in client.get("/notifications", headers=admin).json())
    assert client.post("/notifications/read", headers=admin).status_code == 204
    assert all(n["is_read"] for n in client.get("/notifications", headers=admin).json())
