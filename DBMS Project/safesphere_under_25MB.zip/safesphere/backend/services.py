"""Notification helpers (the 'database + real-time notifications' box of the design).
The frontend polls GET /notifications every few seconds."""
from pymongo.database import Database

from database import NO_ID, next_id
from geo import haversine_km
from models import utcnow


def notify(db: Database, user_ids, title: str, message: str, kind: str = "info", level: str = "info") -> int:
    ids = set(user_ids)
    now = utcnow()
    docs = [{"notification_id": next_id(db, "notifications"), "user_id": uid, "title": title[:150],
             "message": message, "kind": kind, "level": level, "is_read": False, "created_at": now}
            for uid in ids]
    if docs:
        db.notifications.insert_many(docs)
    return len(ids)


def admin_ids(db: Database) -> list[int]:
    return [u["user_id"] for u in db.users.find({"role": "admin"}, {"_id": 0, "user_id": 1})]


def users_within(db: Database, lat: float, lng: float, radius_km: float) -> list[int]:
    return [loc["user_id"] for loc in db.user_locations.find({}, NO_ID)
            if haversine_km(lat, lng, loc["latitude"], loc["longitude"]) <= radius_km]
