import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

load_dotenv(Path(__file__).resolve().parent / ".env")

import routes_auth  # noqa: E402
import routes_public  # noqa: E402
import routes_safety  # noqa: E402
import routes_user  # noqa: E402
from bootstrap import init_db  # noqa: E402
from database import MONGO_DB_NAME, SAFE_URL  # noqa: E402
from security import SECRET_KEY  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
log = logging.getLogger("safesphere")


@asynccontextmanager
async def lifespan(_: FastAPI):
    log.info("Database: MongoDB  %s  (db: %s)", SAFE_URL, MONGO_DB_NAME)
    init_db()
    if SECRET_KEY == "dev-only-secret-change-me":
        log.warning("SECRET_KEY is the built-in default. Set your own in backend/.env before deploying.")
    log.info("SafeSphere API ready  ->  http://127.0.0.1:8000/docs")
    yield


app = FastAPI(title="SafeSphere - Disaster Alert & Community Response API", version="2.0.0", lifespan=lifespan)

origins = [o.strip() for o in os.getenv(
    "CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    # any port on localhost / 127.0.0.1 (Vite moves to 5174, 5175... if 5173 is busy)
    allow_origin_regex=r"https?://(localhost|127\.0\.0\.1)(:\d+)?",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(routes_auth.router)
app.include_router(routes_public.router)
app.include_router(routes_user.router)
app.include_router(routes_safety.router)


@app.get("/", tags=["Health"])
def root():
    return {"status": "ok", "docs": "/docs"}
