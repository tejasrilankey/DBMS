"""Alerts, shelters and emergency services: anyone can READ, only admins can WRITE."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pymongo.database import Database

from database import NO_ID, get_db, insert
from geo import haversine_km
from models import utcnow
from schemas import (AlertCreate, AlertOut, ServiceCreate, ServiceOut,
                     ShelterCreate, ShelterOut, ShelterSlotsUpdate, Stats)
from security import require_admin
from services import notify, users_within

router = APIRouter()


# ---------- Dashboard numbers (public) ----------
@router.get("/stats", response_model=Stats, tags=["Dashboard"])
def stats(db: Database = Depends(get_db)):
    def count(name):
        return db[name].count_documents({})
    return Stats(alerts=count("disaster_alerts"), incidents=count("incident_reports"),
                 help_requests=count("help_requests"), shelters=count("shelters"),
                 volunteers_responses=count("community_responses"))


# ---------- Disaster alerts ----------
@router.get("/disaster-alerts", response_model=list[AlertOut], tags=["Disaster Alerts"])
def list_alerts(lat: Optional[float] = Query(default=None, ge=-90, le=90),
                lng: Optional[float] = Query(default=None, ge=-180, le=180),
                db: Database = Depends(get_db)):
    """With ?lat=&lng= only alerts whose affected area (centre + radius) covers that point are returned.
    Alerts with no coordinates are region-wide and always returned. Without lat/lng: everything."""
    alerts = list(db.disaster_alerts.find({}, NO_ID).sort("alert_time", -1))
    if lat is None or lng is None:
        return alerts
    return [a for a in alerts
            if a.get("latitude") is None or a.get("longitude") is None or a.get("radius_km") is None
            or haversine_km(lat, lng, a["latitude"], a["longitude"]) <= a["radius_km"]]


@router.post("/disaster-alerts", response_model=AlertOut, status_code=201,
             tags=["Disaster Alerts"], dependencies=[Depends(require_admin)])
def create_alert(data: AlertCreate, db: Database = Depends(get_db)):
    alert = insert(db, "disaster_alerts", "disaster_id", {**data.model_dump(), "alert_time": utcnow()})
    # Find users in the affected area and notify only them
    if alert.get("latitude") is not None and alert.get("longitude") is not None and alert.get("radius_km"):
        ids = users_within(db, alert["latitude"], alert["longitude"], alert["radius_km"])
        notify(db, ids, f"{alert['severity'].upper()} alert: {alert['title']}",
               f"{alert['disaster_type']} - {alert['location']}. {alert.get('safety_instructions') or alert.get('description') or ''}".strip(),
               kind="alert", level="critical" if alert["severity"] in ("High", "Critical") else "warning")
    return alert


@router.delete("/disaster-alerts/{disaster_id}", status_code=status.HTTP_204_NO_CONTENT,
               tags=["Disaster Alerts"], dependencies=[Depends(require_admin)])
def delete_alert(disaster_id: int, db: Database = Depends(get_db)):
    if db.disaster_alerts.delete_one({"disaster_id": disaster_id}).deleted_count == 0:
        raise HTTPException(404, "Alert not found")
    # ON DELETE SET NULL
    db.incident_reports.update_many({"disaster_id": disaster_id}, {"$set": {"disaster_id": None}})
    db.community_responses.update_many({"disaster_id": disaster_id}, {"$set": {"disaster_id": None}})


# ---------- Shelters ----------
@router.get("/shelters", response_model=list[ShelterOut], tags=["Shelters"])
def list_shelters(db: Database = Depends(get_db)):
    return list(db.shelters.find({}, NO_ID).sort("shelter_name", 1))


@router.post("/shelters", response_model=ShelterOut, status_code=201,
             tags=["Shelters"], dependencies=[Depends(require_admin)])
def create_shelter(data: ShelterCreate, db: Database = Depends(get_db)):
    if data.available_slots > data.capacity:
        raise HTTPException(400, "available_slots cannot exceed capacity")
    return insert(db, "shelters", "shelter_id", data.model_dump())


@router.patch("/shelters/{shelter_id}/slots", response_model=ShelterOut, tags=["Shelters"],
              dependencies=[Depends(require_admin)])
def update_shelter_slots(shelter_id: int, data: ShelterSlotsUpdate, db: Database = Depends(get_db)):
    shelter = db.shelters.find_one({"shelter_id": shelter_id}, NO_ID)
    if not shelter:
        raise HTTPException(404, "Shelter not found")
    if data.available_slots > shelter["capacity"]:
        raise HTTPException(400, "available_slots cannot exceed capacity")
    db.shelters.update_one({"shelter_id": shelter_id}, {"$set": {"available_slots": data.available_slots}})
    shelter["available_slots"] = data.available_slots
    return shelter


@router.delete("/shelters/{shelter_id}", status_code=status.HTTP_204_NO_CONTENT,
               tags=["Shelters"], dependencies=[Depends(require_admin)])
def delete_shelter(shelter_id: int, db: Database = Depends(get_db)):
    if db.shelters.delete_one({"shelter_id": shelter_id}).deleted_count == 0:
        raise HTTPException(404, "Shelter not found")
    # ON DELETE SET NULL
    db.emergency_services.update_many({"shelter_id": shelter_id}, {"$set": {"shelter_id": None}})
    db.community_responses.update_many({"shelter_id": shelter_id}, {"$set": {"shelter_id": None}})


# ---------- Emergency services ----------
@router.get("/emergency-services", response_model=list[ServiceOut], tags=["Emergency Services"])
def list_services(db: Database = Depends(get_db)):
    return list(db.emergency_services.find({}, NO_ID).sort("service_name", 1))


@router.post("/emergency-services", response_model=ServiceOut, status_code=201,
             tags=["Emergency Services"], dependencies=[Depends(require_admin)])
def create_service(data: ServiceCreate, db: Database = Depends(get_db)):
    if data.shelter_id is not None and not db.shelters.find_one({"shelter_id": data.shelter_id}):
        raise HTTPException(400, "shelter_id does not exist")
    return insert(db, "emergency_services", "service_id", {**data.model_dump(), "contact_id": None})


@router.delete("/emergency-services/{service_id}", status_code=status.HTTP_204_NO_CONTENT,
               tags=["Emergency Services"], dependencies=[Depends(require_admin)])
def delete_service(service_id: int, db: Database = Depends(get_db)):
    if db.emergency_services.delete_one({"service_id": service_id}).deleted_count == 0:
        raise HTTPException(404, "Service not found")
