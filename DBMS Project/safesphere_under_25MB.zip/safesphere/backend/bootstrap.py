"""Runs once when the API starts: connects to MongoDB, creates indexes, seeds sample data into EMPTY collections."""
import logging
import os
from datetime import timedelta

from pymongo.errors import PyMongoError

from database import MONGO_DB_NAME, SAFE_URL, client, db, insert
from models import ensure_indexes, utcnow
from security import hash_password

log = logging.getLogger("safesphere")


def _is_empty(coll: str) -> bool:
    return db[coll].count_documents({}, limit=1) == 0


def _seed() -> None:
    now = utcnow()

    if _is_empty("disaster_alerts"):
        for a in [
            dict(disaster_type="Flood", title="Flood Warning", severity="High", location="Riverside",
                 description="Heavy rainfall may cause flooding in low-lying areas.",
                 alert_time=now - timedelta(minutes=10), latitude=17.3616, longitude=78.4747, radius_km=8,
                 safety_instructions="Move to higher ground. Do not walk or drive through flood water. Switch off mains power.",
                 evacuation_info="Evacuate low-lying streets near the river. Shelters: Government School (Sector 5), Community Hall (Lake View).",
                 source="State Disaster Management Authority", verified=True),
            dict(disaster_type="Cyclone", title="Cyclone Alert", severity="Medium", location="East Coast",
                 description="Strong winds expected in coastal regions.",
                 alert_time=now - timedelta(minutes=30), latitude=16.5, longitude=81.8, radius_km=80,
                 safety_instructions="Stay indoors, secure loose objects and keep a torch and radio ready.",
                 evacuation_info="Coastal villages should move to cyclone shelters when told to.",
                 source="India Meteorological Department", verified=True),
            dict(disaster_type="Earthquake", title="Earthquake Advisory", severity="Low", location="Central Zone",
                 description="Minor tremors detected. Stay alert.",
                 alert_time=now - timedelta(hours=1), latitude=17.44, longitude=78.39, radius_km=25,
                 safety_instructions="Drop, cover and hold on during shaking. Stay away from windows.",
                 evacuation_info="No evacuation needed.", source="National Centre for Seismology", verified=True)]:
            insert(db, "disaster_alerts", "disaster_id", a)
    if _is_empty("shelters"):
        for s in [dict(shelter_name="Government School", location="Sector 5", capacity=500, available_slots=180,
                       contact="9876543210", latitude=17.4062, longitude=78.4691),
                  dict(shelter_name="Community Hall", location="Lake View", capacity=300, available_slots=120,
                       contact="9876500000", latitude=17.4239, longitude=78.4738)]:
            insert(db, "shelters", "shelter_id", s)
    if _is_empty("emergency_services"):
        for s in [("Hospital", "Medical", "108", "Central Hospital", 17.4126, 78.4483),
                  ("Police", "Police", "100", "Main Road Station", 17.3901, 78.4744),
                  ("Fire Station", "Fire", "101", "Fire Station Road", 17.4001, 78.4566),
                  ("Disaster Management", "Disaster", "112", "Control Room", 17.3850, 78.4867)]:
            insert(db, "emergency_services", "service_id", dict(
                service_name=s[0], service_type=s[1], phone=s[2], availability="24x7", location=s[3],
                latitude=s[4], longitude=s[5], contact_id=None, shelter_id=None))

    # ---- demo accounts + sample activity (fresh database only) ----
    if os.getenv("SEED_DEMO", "true").lower() not in ("1", "true", "yes") or not _is_empty("users"):
        return

    def user(name, email, role, password, phone=None):
        return insert(db, "users", "user_id", dict(name=name, email=email, role=role, phone=phone,
                                                    password_hash=hash_password(password)))

    admin = user("Admin", "admin@safesphere.com", "admin", "admin123", "9000000001")
    rahul = user("Rahul", "volunteer@safesphere.com", "volunteer", "volunteer123", "9000000002")
    priya = user("Priya", "citizen@safesphere.com", "citizen", "citizen123", "9000000003")
    arjun = user("Arjun", "arjun@example.com", "citizen", "citizen123", "9000000004")
    sneha = user("Sneha", "sneha@example.com", "citizen", "citizen123", "9000000005")

    db.user_locations.insert_many([
        dict(user_id=priya["user_id"], latitude=17.3990, longitude=78.4780, updated_at=now),
        dict(user_id=rahul["user_id"], latitude=17.4050, longitude=78.4700, updated_at=now),
        dict(user_id=arjun["user_id"], latitude=17.4230, longitude=78.4730, updated_at=now)])
    db.volunteer_profiles.insert_one(dict(
        user_id=rahul["user_id"], skills=["First Aid", "Driving", "Rescue"],
        resources=["Car", "First-aid kit", "Water"], location="Hyderabad", available=True, updated_at=now))

    insert(db, "incident_reports", "incident_id", dict(
        user_id=rahul["user_id"], disaster_id=None, incident_type="Flood", location="Main Road",
        description="Road submerged due to heavy rain.", status="Pending", latitude=17.3950, longitude=78.4800,
        severity="High", people_affected=12, created_at=now - timedelta(minutes=8), is_sos=False,
        reporter_name="Rahul"))
    insert(db, "incident_reports", "incident_id", dict(
        user_id=sneha["user_id"], disaster_id=None, incident_type="Fire", location="Industrial Area",
        description="Small warehouse fire.", status="Resolved", latitude=17.4500, longitude=78.3900,
        severity="Medium", people_affected=3, created_at=now - timedelta(hours=5), is_sos=False,
        reporter_name="Sneha"))
    insert(db, "help_requests", "request_id", dict(
        user_id=priya["user_id"], request_type="Medical Help", priority="Critical", location="Sector 12",
        description="Elderly relative needs urgent medical help.", status="Pending", latitude=17.4010,
        longitude=78.4760, created_at=now - timedelta(minutes=5), requester_name="Priya"))
    h2 = insert(db, "help_requests", "request_id", dict(
        user_id=arjun["user_id"], request_type="Food", priority="Medium", location="Lake View",
        description="Family of five needs food supplies.", status="Accepted", latitude=17.4230,
        longitude=78.4730, created_at=now - timedelta(minutes=40), requester_name="Arjun"))
    insert(db, "community_responses", "response_id", dict(
        request_id=h2["request_id"], volunteer_id=rahul["user_id"], response_type="Supplies",
        message="On my way with food packets.", status="Accepted", disaster_id=None, shelter_id=None,
        volunteer_name="Rahul", request_type="Food"))

    for uid, name, rel, phone in [(priya["user_id"], "Father", "Parent", "9876543210"),
                                  (priya["user_id"], "Mother", "Parent", "9876501234"),
                                  (priya["user_id"], "Arjun", "Brother", "9000000004"),
                                  (arjun["user_id"], "Priya", "Sister", "9000000003")]:
        insert(db, "emergency_contacts", "contact_id",
               dict(user_id=uid, contact_name=name, relationship=rel, phone=phone))
    insert(db, "safety_checkins", "checkin_id", dict(
        user_id=arjun["user_id"], status="Needs help", shared=True, note="Water is entering the ground floor.",
        created_at=now - timedelta(minutes=12)))
    log.info("Seeded demo accounts (admin@safesphere.com / admin123, volunteer@safesphere.com / volunteer123, "
             "citizen@safesphere.com / citizen123)")


def init_db() -> None:
    try:
        client.admin.command("ping")
    except PyMongoError as exc:
        raise RuntimeError(
            "\n\nCould not connect to MongoDB.\n"
            f"  URL: {SAFE_URL}  (db: {MONGO_DB_NAME})\n"
            "  - Is the MongoDB server running? Are MONGO_URL / MONGO_DB_NAME in backend/.env correct?\n"
            f"\nOriginal error: {exc}\n") from exc
    ensure_indexes(db)
    _seed()
