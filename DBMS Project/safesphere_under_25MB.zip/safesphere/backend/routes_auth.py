from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from pymongo.database import Database
from pymongo.errors import DuplicateKeyError

from database import NO_ID, get_db, insert
from models import User
from schemas import Token, UserCreate, UserOut
from security import create_access_token, get_current_user, hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", response_model=Token, status_code=status.HTTP_201_CREATED)
def register(data: UserCreate, db: Database = Depends(get_db)):
    email = data.email.lower()
    if db.users.find_one({"email": email}):
        raise HTTPException(status_code=400, detail="Email is already registered")
    try:
        doc = insert(db, "users", "user_id", dict(name=data.name.strip(), email=email, phone=data.phone,
                                                  role=data.role, password_hash=hash_password(data.password)))
    except DuplicateKeyError:
        raise HTTPException(status_code=400, detail="Email is already registered")
    user = User(**doc)
    return Token(access_token=create_access_token(user), user=UserOut.model_validate(user))


@router.post("/login", response_model=Token)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Database = Depends(get_db)):
    # OAuth2 form field is called "username" - we treat it as the email
    doc = db.users.find_one({"email": form.username.lower()}, NO_ID)
    if not doc or not doc.get("password_hash") or not verify_password(form.password, doc["password_hash"]):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    user = User(**doc)
    return Token(access_token=create_access_token(user), user=UserOut.model_validate(user))


@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(get_current_user)):
    return UserOut.model_validate(current_user)
