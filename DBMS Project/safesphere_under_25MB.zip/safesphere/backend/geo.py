"""Small geo / phone helpers."""
from math import asin, cos, radians, sin, sqrt


def haversine_km(lat1, lng1, lat2, lng2) -> float:
    p1, p2 = radians(lat1), radians(lat2)
    dphi, dlmb = p2 - p1, radians(lng2 - lng1)
    a = sin(dphi / 2) ** 2 + cos(p1) * cos(p2) * sin(dlmb / 2) ** 2
    return 2 * 6371.0 * asin(sqrt(a))


def norm_phone(p) -> str:
    """Digits only, last 10 - so '+91 98765-43210' == '9876543210'."""
    digits = "".join(c for c in (p or "") if c.isdigit())
    return digits[-10:]
