"""MongoDB connection (PyMongo).

Configure in backend/.env:
  MONGO_URL      mongodb://localhost:27017   or an Atlas string  mongodb+srv://user:pass@cluster/...
  MONGO_DB_NAME  database name (created automatically on first write), default "safesphere"

IDs: every collection keeps the same integer id field as before (user_id, incident_id ...),
handed out by a small "counters" collection, so the API and the frontend do not change.
"""
import os
import re
from pathlib import Path

from dotenv import load_dotenv
from pymongo import MongoClient, ReturnDocument
from pymongo.database import Database

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017").strip()
MONGO_DB_NAME = os.getenv("MONGO_DB_NAME", "safesphere").strip()
SAFE_URL = re.sub(r"://([^:/@]+):[^@]*@", r"://\1:***@", MONGO_URL)   # hide the password in logs

# MongoClient is thread-safe, so one shared client works with FastAPI's thread pool
client = MongoClient(MONGO_URL, serverSelectionTimeoutMS=5000)
db: Database = client[MONGO_DB_NAME]

NO_ID = {"_id": 0}   # projection: hide Mongo's internal ObjectId


def get_db() -> Database:
    return db


def next_id(database: Database, name: str) -> int:
    """Auto-increment integer id (like AUTO_INCREMENT in MySQL)."""
    doc = database.counters.find_one_and_update(
        {"_id": name}, {"$inc": {"seq": 1}}, upsert=True, return_document=ReturnDocument.AFTER)
    return doc["seq"]


def insert(database: Database, collection: str, id_field: str, doc: dict) -> dict:
    """Insert a document with a fresh integer id and return it (without Mongo's _id)."""
    doc[id_field] = next_id(database, collection)
    database[collection].insert_one(doc)
    doc.pop("_id", None)
    return doc
