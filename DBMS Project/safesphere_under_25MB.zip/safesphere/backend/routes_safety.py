"""SOS, live map, volunteers + matching, assignment, family check-in, notifications."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Response
from pymongo.database import Database

from database import NO_ID, get_db, insert
from geo import haversine_km, norm_phone
from models import User, utcnow
from schemas import (AssignIn, CheckinCreate, CheckinOut, FamilyMember, LocationIn, MapOut, MapVolunteer,
                     NearbyPlace, NotificationOut, ResponseOut, ResponseStatusUpdate, SOSContact, SOSCreate,
                     SOSOut, VolunteerMatch, VolunteerProfileIn, VolunteerProfileOut)
from security import get_current_user, require_admin, require_responder
from services import admin_ids, notify, users_within

router = APIRouter()

SOS_PRIORITY = {"Medical emergency": "Critical", "Trapped": "Critical", "Fire": "Critical",
                "Flood": "High", "Accident": "High", "Missing person": "High", "Other": "Medium"}
HAS_POS = {"latitude": {"$ne": None}, "longitude": {"$ne": None}}


def _save_location(db: Database, user_id: int, lat: float, lng: float) -> None:
    db.user_locations.update_one({"user_id": user_id},
                                 {"$set": {"latitude": lat, "longitude": lng, "updated_at": utcnow()}}, upsert=True)


@router.put("/me/location", tags=["Location"])
def update_my_location(data: LocationIn, db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    _save_location(db, user.user_id, data.latitude, data.longitude)
    return {"ok": True}


def _contact_users(db: Database, user: User) -> dict[str, int]:
    """normalised phone -> user_id of every OTHER SafeSphere user."""
    out = {}
    for u in db.users.find({"phone": {"$ne": None}, "user_id": {"$ne": user.user_id}}, {"_id": 0, "user_id": 1, "phone": 1}):
        p = norm_phone(u["phone"])
        if p:
            out[p] = u["user_id"]
    return out


# ---------------------------------------------------------------- SOS
def _nearby(items, lat, lng, id_key, name_key, place_key, phone_key, limit=3) -> list[NearbyPlace]:
    out = []
    for it in items:
        d = None
        if lat is not None and lng is not None and it.get("latitude") is not None and it.get("longitude") is not None:
            d = round(haversine_km(lat, lng, it["latitude"], it["longitude"]), 2)
        out.append(NearbyPlace(id=it[id_key], name=it[name_key], location=it.get(place_key), phone=it.get(phone_key),
                               latitude=it.get("latitude"), longitude=it.get("longitude"), distance_km=d))
    out.sort(key=lambda p: (p.distance_km is None, p.distance_km or 0))
    return out[:limit]


@router.post("/sos", response_model=SOSOut, status_code=201, tags=["SOS"])
def send_sos(data: SOSCreate, db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    """SOS -> location -> incident -> emergency contacts -> response team -> nearby shelters/hospitals."""
    priority = SOS_PRIORITY[data.sos_type]
    lat, lng = data.latitude, data.longitude
    has_pos = lat is not None and lng is not None
    if has_pos:
        _save_location(db, user.user_id, lat, lng)
    where = data.location or (f"{lat:.5f}, {lng:.5f}" if has_pos else "Location unavailable")
    text = data.description or f"SOS - {data.sos_type}"
    now = utcnow()

    incident = insert(db, "incident_reports", "incident_id", dict(
        user_id=user.user_id, disaster_id=None, incident_type=data.sos_type, description=text, location=where,
        latitude=lat, longitude=lng, status="Pending", is_sos=True,
        severity=priority if priority in ("Critical", "High") else "Medium",
        people_affected=data.people_affected, created_at=now, reporter_name=user.name))
    help_req = insert(db, "help_requests", "request_id", dict(
        user_id=user.user_id, request_type=f"SOS - {data.sos_type}", description=text, location=where,
        latitude=lat, longitude=lng, priority=priority, status="Pending", created_at=now,
        requester_name=user.name))

    # emergency contacts (in-app notification if the contact is also a SafeSphere user)
    contacts = list(db.emergency_contacts.find({"user_id": user.user_id}, NO_ID))
    by_phone = _contact_users(db, user)
    contact_out, family_ids = [], []
    for c in contacts:
        uid = by_phone.get(norm_phone(c["phone"]))
        if uid is not None:
            family_ids.append(uid)
        contact_out.append(SOSContact(contact_name=c["contact_name"], relationship=c.get("relationship"),
                                      phone=c["phone"], in_app=uid is not None))
    msg = f"{user.name} sent an SOS ({data.sos_type}) from {where}."
    notify(db, family_ids, f"SOS from {user.name}", msg, kind="sos", level="critical")

    # authorised response team + available volunteers within 10 km
    team = notify(db, admin_ids(db), f"{priority} SOS: {data.sos_type}", msg + " Open the Command Center.",
                  kind="sos", level="critical")
    vols = 0
    if has_pos:
        avail = set(db.volunteer_profiles.distinct("user_id", {"available": True}))
        ids = [i for i in users_within(db, lat, lng, 10) if i in avail and i != user.user_id]
        vols = notify(db, ids, f"Someone nearby needs help ({data.sos_type})", msg, kind="sos", level="critical")

    shelters = _nearby(list(db.shelters.find({}, NO_ID)), lat, lng, "shelter_id", "shelter_name", "location", "contact")
    hospitals = _nearby(list(db.emergency_services.find({"service_type": "Medical"}, NO_ID)),
                        lat, lng, "service_id", "service_name", "location", "phone")
    return SOSOut(incident_id=incident["incident_id"], request_id=help_req["request_id"], priority=priority,
                  contacts=contact_out, notified_response_team=team, notified_volunteers=vols,
                  nearby_shelters=shelters, nearby_hospitals=hospitals)


# ---------------------------------------------------------------- live map
@router.get("/map", response_model=MapOut, tags=["Map"])
def live_map(db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    alerts = list(db.disaster_alerts.find(HAS_POS, NO_ID))
    incidents = list(db.incident_reports.find({"status": {"$ne": "Resolved"}, "latitude": {"$ne": None}}, NO_ID))
    shelters = list(db.shelters.find({"latitude": {"$ne": None}}, NO_ID))
    svcs = list(db.emergency_services.find({"latitude": {"$ne": None}}, NO_ID))
    vols = []
    if user.role in ("volunteer", "admin"):        # volunteer positions are not shown to ordinary citizens
        profiles = list(db.volunteer_profiles.find({"available": True}, NO_ID))
        ids = [p["user_id"] for p in profiles]
        users = {u["user_id"]: u for u in db.users.find({"user_id": {"$in": ids}}, NO_ID)}
        locs = {l["user_id"]: l for l in db.user_locations.find({"user_id": {"$in": ids}}, NO_ID)}
        vols = [MapVolunteer(user_id=p["user_id"], name=users[p["user_id"]]["name"], skills=p.get("skills", []),
                             latitude=locs[p["user_id"]]["latitude"], longitude=locs[p["user_id"]]["longitude"])
                for p in profiles if p["user_id"] in users and p["user_id"] in locs]
    return MapOut(alerts=alerts, incidents=incidents, shelters=shelters,
                  hospitals=[s for s in svcs if s["service_type"] == "Medical"],
                  services=[s for s in svcs if s["service_type"] != "Medical"], volunteers=vols)


# ---------------------------------------------------------------- volunteers
def _profile_out(db: Database, u: dict, p: Optional[dict]) -> VolunteerProfileOut:
    loc = db.user_locations.find_one({"user_id": u["user_id"]}, NO_ID)
    return VolunteerProfileOut(user_id=u["user_id"], name=u["name"], phone=u.get("phone"),
                               skills=p.get("skills", []) if p else [], resources=p.get("resources", []) if p else [],
                               location=p.get("location") if p else None, available=bool(p.get("available")) if p else False,
                               latitude=loc["latitude"] if loc else None, longitude=loc["longitude"] if loc else None)


def _profiles_with_users(db: Database, only_available: bool = False):
    q = {"available": True} if only_available else {}
    profiles = list(db.volunteer_profiles.find(q, NO_ID))
    users = {u["user_id"]: u for u in db.users.find({"user_id": {"$in": [p["user_id"] for p in profiles]}}, NO_ID)}
    return [(users[p["user_id"]], p) for p in profiles if p["user_id"] in users]


@router.get("/volunteers/me", response_model=VolunteerProfileOut, tags=["Volunteers"])
def my_profile(db: Database = Depends(get_db), user: User = Depends(require_responder)):
    return _profile_out(db, vars(user), db.volunteer_profiles.find_one({"user_id": user.user_id}, NO_ID))


@router.put("/volunteers/me", response_model=VolunteerProfileOut, tags=["Volunteers"])
def save_profile(data: VolunteerProfileIn, db: Database = Depends(get_db), user: User = Depends(require_responder)):
    db.volunteer_profiles.update_one({"user_id": user.user_id}, {"$set": {
        "skills": list(dict.fromkeys(data.skills)),
        "resources": list(dict.fromkeys(r.strip() for r in data.resources if r.strip())),
        "location": data.location, "available": data.available, "updated_at": utcnow()}}, upsert=True)
    return _profile_out(db, vars(user), db.volunteer_profiles.find_one({"user_id": user.user_id}, NO_ID))


@router.get("/volunteers", response_model=list[VolunteerProfileOut], tags=["Volunteers"])
def list_volunteers(db: Database = Depends(get_db), _: User = Depends(require_responder)):
    out = [_profile_out(db, u, p) for u, p in _profiles_with_users(db)]
    out.sort(key=lambda v: not v.available)
    return out


def _wanted_skills(text: str) -> set[str]:
    t = text.lower()
    s: set[str] = set()
    if any(k in t for k in ("medical", "injur", "health")):
        s |= {"Medical", "First Aid"}
    if any(k in t for k in ("rescue", "trapped", "fire", "flood", "missing")):
        s.add("Rescue")
    if any(k in t for k in ("food", "water", "shelter", "evac", "accident")):
        s.add("Driving")
    if "accident" in t:
        s |= {"First Aid", "Medical"}
    return s


@router.get("/help-requests/{request_id}/matches", response_model=list[VolunteerMatch], tags=["Command Center"],
            dependencies=[Depends(require_admin)])
def match_volunteers(request_id: int, db: Database = Depends(get_db)):
    """Rank available volunteers for a help request by skills, resources and distance."""
    req = db.help_requests.find_one({"request_id": request_id}, NO_ID)
    if not req:
        raise HTTPException(404, "Help request not found")
    wanted = _wanted_skills(f"{req['request_type']} {req.get('description') or ''}")
    text = f"{req['request_type']} {req.get('description') or ''}".lower()
    out = []
    for u, p in _profiles_with_users(db, only_available=True):
        base = _profile_out(db, u, p)
        score, reasons = 0, []
        hit = wanted & set(base.skills)
        if hit:
            score += 10 * len(hit)
            reasons.append("Skills: " + ", ".join(sorted(hit)))
        for r in base.resources:
            if r.lower().split()[0] in text or (r.lower().startswith("first") and "medical" in text) \
                    or (r.lower() == "car" and "Driving" in wanted):
                score += 2
                reasons.append(f"Has {r}")
        if req.get("latitude") is not None and base.latitude is not None:
            d = round(haversine_km(req["latitude"], req["longitude"], base.latitude, base.longitude), 2)
            base.distance_km = d
            score += max(0, 10 - int(d))
            reasons.append(f"{d} km away")
        out.append(VolunteerMatch(**base.model_dump(), score=score, reasons=reasons))
    out.sort(key=lambda m: -m.score)
    return out


@router.post("/help-requests/{request_id}/assign", response_model=ResponseOut, status_code=201,
             tags=["Command Center"])
def assign_volunteer(request_id: int, data: AssignIn, db: Database = Depends(get_db),
                     admin: User = Depends(require_admin)):
    req = db.help_requests.find_one({"request_id": request_id}, NO_ID)
    vol = db.users.find_one({"user_id": data.volunteer_id}, NO_ID)
    if not req:
        raise HTTPException(404, "Help request not found")
    if not vol or vol["role"] not in ("volunteer", "admin"):
        raise HTTPException(400, "Choose a registered volunteer")
    if req["status"] in ("Completed", "Cancelled"):
        raise HTTPException(400, f"This request is already {req['status'].lower()}")
    if db.community_responses.find_one({"request_id": request_id, "volunteer_id": vol["user_id"]}):
        raise HTTPException(400, "This volunteer is already assigned to the request")
    resp = insert(db, "community_responses", "response_id", dict(
        request_id=request_id, volunteer_id=vol["user_id"], response_type=req["request_type"][:50],
        message=data.message or "Assigned by the Command Center", status="Assigned", disaster_id=None,
        shelter_id=None, volunteer_name=vol["name"], request_type=req["request_type"]))
    if req["status"] == "Pending":
        db.help_requests.update_one({"request_id": request_id}, {"$set": {"status": "Accepted"}})
    notify(db, [vol["user_id"]], f"New assignment: {req['request_type']}",
           f"{req['priority']} priority at {req.get('location') or 'unknown location'}. Open Help Requests to accept.",
           kind="assignment", level="critical" if req["priority"] == "Critical" else "warning")
    notify(db, [req["user_id"]], "A volunteer has been assigned", f"{vol['name']} is assigned to your request.", kind="help")
    return resp


@router.patch("/community-responses/{response_id}/status", response_model=ResponseOut, tags=["Community Responses"])
def update_response_status(response_id: int, data: ResponseStatusUpdate, db: Database = Depends(get_db),
                           user: User = Depends(get_current_user)):
    r = db.community_responses.find_one({"response_id": response_id}, NO_ID)
    if not r:
        raise HTTPException(404, "Response not found")
    if r["volunteer_id"] != user.user_id and user.role != "admin":
        raise HTTPException(403, "Only the assigned volunteer or an admin can update this")
    db.community_responses.update_one({"response_id": response_id}, {"$set": {"status": data.status}})
    r["status"] = data.status
    req = db.help_requests.find_one({"request_id": r["request_id"]}, NO_ID)
    if req and data.status == "Completed":
        db.help_requests.update_one({"request_id": req["request_id"]}, {"$set": {"status": "Completed"}})
        notify(db, [req["user_id"]], "Your help request was completed", f"{r['volunteer_name']} marked it completed.", kind="help")
    elif req and data.status == "Declined":
        others = db.community_responses.find_one({
            "request_id": req["request_id"], "response_id": {"$ne": response_id},
            "status": {"$in": ["Assigned", "Accepted"]}})
        if not others and req["status"] == "Accepted":
            db.help_requests.update_one({"request_id": req["request_id"]}, {"$set": {"status": "Pending"}})
        notify(db, admin_ids(db), "Assignment declined", f"{r['volunteer_name']} declined {req['request_type']}. Reassign it.",
               kind="assignment", level="warning")
    return r


# ---------------------------------------------------------------- family safety check-in
@router.post("/checkins", response_model=CheckinOut, status_code=201, tags=["Family Safety"])
def check_in(data: CheckinCreate, db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    c = insert(db, "safety_checkins", "checkin_id", dict(
        user_id=user.user_id, status=data.status, note=data.note, shared=data.share_with_contacts,
        created_at=utcnow()))
    notified = 0
    if data.share_with_contacts:
        users = _contact_users(db, user)
        phones = {norm_phone(x["phone"]) for x in db.emergency_contacts.find({"user_id": user.user_id}, NO_ID)}
        ids = [users[p] for p in phones if p in users]
        ok = data.status == "Safe"
        notified = notify(db, ids, f"{user.name} has checked in as {'SAFE' if ok else 'NEEDS HELP'}",
                          data.note or "", kind="family", level="info" if ok else "critical")
    return CheckinOut(checkin_id=c["checkin_id"], status=c["status"], note=c["note"], shared=c["shared"],
                      created_at=c["created_at"], notified=notified)


@router.get("/checkins/family", response_model=list[FamilyMember], tags=["Family Safety"])
def family_board(db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    """Status of the people in MY emergency contacts. A member is shown only if they use SafeSphere,
    ticked 'share with contacts' on their latest check-in, and list my phone number as their own contact."""
    users = _contact_users(db, user)
    me = norm_phone(user.phone)
    out = []
    for c in db.emergency_contacts.find({"user_id": user.user_id}, NO_ID).sort("contact_id", 1):
        uid = users.get(norm_phone(c["phone"]))
        status, when = "No update", None
        if uid is not None and me:
            lists_me = any(norm_phone(x["phone"]) == me for x in db.emergency_contacts.find({"user_id": uid}, NO_ID))
            last = db.safety_checkins.find_one({"user_id": uid}, NO_ID, sort=[("checkin_id", -1)])
            if lists_me and last and last["shared"]:
                status, when = last["status"], last["created_at"]
        out.append(FamilyMember(contact_id=c["contact_id"], contact_name=c["contact_name"],
                                relationship=c.get("relationship"), phone=c["phone"], status=status,
                                updated_at=when, on_safesphere=uid is not None))
    return out


@router.get("/checkins/me", response_model=list[CheckinOut], tags=["Family Safety"])
def my_checkins(db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    return list(db.safety_checkins.find({"user_id": user.user_id}, NO_ID).sort("checkin_id", -1).limit(5))


# ---------------------------------------------------------------- notifications (polled by the UI)
@router.get("/notifications", response_model=list[NotificationOut], tags=["Notifications"])
def my_notifications(db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    return list(db.notifications.find({"user_id": user.user_id}, NO_ID).sort("notification_id", -1).limit(30))


@router.post("/notifications/read", status_code=204, tags=["Notifications"])
def mark_all_read(db: Database = Depends(get_db), user: User = Depends(get_current_user)):
    db.notifications.update_many({"user_id": user.user_id, "is_read": False}, {"$set": {"is_read": True}})
    return Response(status_code=204)
