# SafeSphere – Disaster Alert & Community Response

FastAPI backend + React (Vite) frontend. Works out of the box, no database setup.
Needs internet for the map tiles (OpenStreetMap) and `npm install` (adds `leaflet`).

## Run (2 terminals)
| | Windows | Mac/Linux |
|---|---|---|
| 1. Backend  (port 8000) | double-click `run_backend.bat` | `./run_backend.sh` |
| 2. Frontend (port 5173) | double-click `run_frontend.bat` | `./run_frontend.sh` |

Allow location access in the browser for live alerts. Open http://localhost:5173  (API docs: http://127.0.0.1:8000/docs)

Requirements: Python 3.10+ and Node 18+.

## Demo logins (created on first run)
| Role | Email | Password |
|---|---|---|
| Admin | admin@safesphere.com | admin123 |
| Volunteer | volunteer@safesphere.com | volunteer123 |
| Citizen | citizen@safesphere.com | citizen123 |

## App structure (matches the design diagram)
**Citizen / Volunteer:** Dashboard -> Alerts, SOS, Live map -> Help request
**Response team (admin):** Command Center -> Reports, Verify, Assign -> Response
Both sides share the database and get notifications (the app polls every 8 seconds).

## Features
1. **Emergency SOS**: pick a type (medical, trapped, fire, flood, accident, missing person, other). Creates an incident + help request, notifies emergency contacts, the response team and volunteers within 10 km, and shows nearby shelters/hospitals.
2. **Live map**: disasters, incidents, volunteers (volunteers/admin only), shelters, hospitals, emergency services, you. Incident popups show distance, severity, time, people affected, status, Request Help and Get Directions.
3. **Location-based alerts**: alerts have a centre + radius. Users only see and get notified about alerts covering their location. Alerts carry type, severity, area, time, safety instructions, evacuation info and source/verified status.
4. **Priority levels** on help requests: Critical, High, Medium, Low. Most urgent first.
5. **Volunteer profiles**: skills, resources, availability. The Command Center ranks volunteers for each request (skills, resources, distance) and assigns them.
6. **Family safety check-in**: "I'm safe" / "I need help" with an explicit share checkbox. Location is never shared. A family member shows on your board only if they use SafeSphere, saved your number and chose to share.

## Database = your ER diagram
The 8 ER tables keep their names, columns and relationships. Extra nullable columns were added (coordinates, timestamps, alert safety fields). Four support tables are new: `user_locations`, `volunteer_profiles`, `safety_checkins`, `notifications`. Existing databases are upgraded automatically on start.

## Roles
* Citizen: SOS, report incidents, request help, family check-in, contacts
* Volunteer: also respond to help requests, accept assignments, volunteer profile
* Admin: Command Center, issue/delete alerts, shelters, verify and assign

## Using MySQL instead of SQLite
Edit `backend/.env`: set `DB_TYPE=mysql` and fill `DB_HOST/DB_USER/DB_PASSWORD/DB_NAME`.
The database, tables and the missing `password_hash` column are created automatically;
your existing Workbench tables keep their data. (`sql/` scripts are no longer required.)
Set `SEED_DEMO=false` to skip demo accounts.

## Tests
`cd backend && pip install pytest httpx && python -m pytest -q`
