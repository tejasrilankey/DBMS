#!/usr/bin/env bash
cd "$(dirname "$0")/backend"
[ -f .env ] || cp .env.example .env
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
pip install -q -r requirements.txt
python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
