-- Run this ONCE in MySQL Workbench.
-- Your users table has no place to store a password, and login needs one.
USE disaster_response_db;

ALTER TABLE users
  ADD COLUMN password_hash VARCHAR(255) NOT NULL DEFAULT '' AFTER role;

-- Check it:
-- DESCRIBE users;
