-- OPTIONAL: sample data so the page is not empty on first run.
USE disaster_response_db;

INSERT INTO disaster_alerts (disaster_type, title, description, severity, location, alert_time) VALUES
('Flood',      'Flood Warning',       'Heavy rainfall may cause flooding in low-lying areas.', 'High',   'Riverside',    NOW() - INTERVAL 10 MINUTE),
('Cyclone',    'Cyclone Alert',       'Strong winds expected in coastal regions.',             'Medium', 'East Coast',   NOW() - INTERVAL 30 MINUTE),
('Earthquake', 'Earthquake Advisory', 'Minor tremors detected. Stay alert.',                   'Low',    'Central Zone', NOW() - INTERVAL 1 HOUR);

INSERT INTO shelters (shelter_name, location, capacity, available_slots, contact) VALUES
('Government School', 'Sector 5',  500, 180, '9876543210'),
('Community Hall',    'Lake View', 300, 120, '9876500000');

INSERT INTO emergency_services (service_name, service_type, phone, availability) VALUES
('Hospital',            'Medical',  '108', '24x7'),
('Police',              'Police',   '100', '24x7'),
('Fire Station',        'Fire',     '101', '24x7'),
('Disaster Management', 'Disaster', '112', '24x7');
