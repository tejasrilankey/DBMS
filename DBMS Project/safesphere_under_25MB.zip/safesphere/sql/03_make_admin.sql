-- OPTIONAL: run AFTER you have signed up in the app.
-- Admins can create alerts / shelters / services and change incident status (via http://127.0.0.1:8000/docs).
USE disaster_response_db;

UPDATE users SET role = 'admin' WHERE email = 'your_email@example.com';
