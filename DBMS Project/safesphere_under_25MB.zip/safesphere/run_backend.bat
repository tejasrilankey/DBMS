@echo off
cd /d "%~dp0backend"
if not exist .env copy .env.example .env >nul
if not exist .venv ( python -m venv .venv )
call .venv\Scripts\activate
pip install -q -r requirements.txt
python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
pause
