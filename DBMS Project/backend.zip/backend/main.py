
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime, timezone
from bson import ObjectId

from database import (
    db,
    users_collection,
    locations_collection,
    resources_collection,
    volunteers_collection,
    requests_collection,
    distributions_collection,
    incidents_collection,
    alerts_collection,
    contacts_collection,
    shelters_collection,
    notifications_collection
)

app = FastAPI(
    title="ReliefGrid API",
    description="Disaster Relief Resource Management System",
    version="1.0.0"
)

# Allow React frontend to connect
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


def serialize(document):
    if document is None:
        return None

    document["_id"] = str(document["_id"])
    return document


def get_records(collection):
    return [serialize(x) for x in collection.find()]


def next_id(collection, field, prefix):
    count = collection.count_documents({})
    return f"{prefix}{count + 1:03d}"


# -------------------------------
# REQUEST MODELS
# -------------------------------

class LocationInput(BaseModel):
    name: str
    district: str
    type: str
    affectedPeople: int = Field(ge=0)
    nearbyVolunteers: Optional[str] = ""
    severity: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None


class VolunteerInput(BaseModel):
    name: str
    skill: str
    location: str
    status: str = "Available"
    phone: Optional[str] = None


class ResourceInput(BaseModel):
    name: str
    category: str
    quantity: int = Field(ge=0)
    unit: str
    status: str = "Available"


class PersonInput(BaseModel):
    name: str
    location: str
    people: int = Field(ge=1)
    priority: str = "Medium"


class RequestInput(BaseModel):
    requester: str
    resource: str
    quantity: int = Field(ge=1)
    location: str
    priority: str
    description: Optional[str] = ""
    latitude: Optional[float] = None
    longitude: Optional[float] = None


class DistributionInput(BaseModel):
    resource: str
    quantity: int = Field(ge=1)
    location: str
    volunteer: str
    date: str


class IncidentInput(BaseModel):
    user_id: str
    incident_type: str
    location: str
    description: str
    people_affected: int = Field(ge=0)
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    severity: str = "Medium"
    is_sos: bool = False
    reporter_name: str


class NotificationStatus(BaseModel):
    read: bool = True


# -------------------------------
# HOME / HEALTH CHECK
# -------------------------------

@app.get("/")
def home():
    return {
        "message": "Welcome to ReliefGrid API",
        "status": "running"
    }


@app.get("/api/health")
def health():
    try:
        db.command("ping")
        return {
            "api": "working",
            "database": "connected"
        }
    except Exception as e:
        raise HTTPException(
            status_code=503,
            detail=f"Database connection failed: {str(e)}"
        )


# -------------------------------
# DASHBOARD
# -------------------------------

@app.get("/api/dashboard")
def dashboard():
    return {
        "active_locations": locations_collection.count_documents(
            {"status": "Active"}
        ),
        "affected_people": sum(
            x.get("affectedPeople", 0)
            for x in locations_collection.find()
        ),
        "available_resources": sum(
            x.get("quantity", 0)
            for x in resources_collection.find()
        ),
        "pending_requests": requests_collection.count_documents(
            {"status": "Pending"}
        ),
        "available_volunteers": volunteers_collection.count_documents(
            {"status": "Available"}
        ),
        "total_distributions": distributions_collection.count_documents({})
    }


# -------------------------------
# LOCATIONS
# -------------------------------

@app.get("/api/locations")
def get_locations():
    return get_records(locations_collection)


@app.post("/api/locations")
def add_location(data: LocationInput):
    record = data.model_dump()

    record["location_id"] = next_id(
        locations_collection, "location_id", "LOC"
    )
    record["status"] = "Active"
    record["created_at"] = datetime.now(timezone.utc)

    locations_collection.insert_one(record)

    return {
        "message": "Location added successfully",
        "data": serialize(locations_collection.find_one(
            {"location_id": record["location_id"]}
        ))
    }


# -------------------------------
# PEOPLE
# -------------------------------

@app.get("/api/people")
def get_people():
    return get_records(users_collection)


@app.post("/api/people")
def add_person(data: PersonInput):
    record = data.model_dump()
    record["user_id"] = next_id(users_collection, "user_id", "P")
    record["status"] = "Registered"
    record["created_at"] = datetime.now(timezone.utc)

    users_collection.insert_one(record)

    return {
        "message": "Person registered successfully",
        "data": serialize(users_collection.find_one(
            {"user_id": record["user_id"]}
        ))
    }


# -------------------------------
# RESOURCES
# -------------------------------

@app.get("/api/resources")
def get_resources():
    return get_records(resources_collection)


@app.post("/api/resources")
def add_resource(data: ResourceInput):
    record = data.model_dump()
    record["resource_id"] = next_id(
        resources_collection, "resource_id", "RES"
    )
    record["created_at"] = datetime.now(timezone.utc)

    resources_collection.insert_one(record)

    return {
        "message": "Resource added successfully",
        "data": serialize(resources_collection.find_one(
            {"resource_id": record["resource_id"]}
        ))
    }


# -------------------------------
# VOLUNTEERS
# -------------------------------

@app.get("/api/volunteers")
def get_volunteers():
    return get_records(volunteers_collection)


@app.post("/api/volunteers")
def add_volunteer(data: VolunteerInput):
    record = data.model_dump()
    record["volunteer_id"] = next_id(
        volunteers_collection, "volunteer_id", "VOL"
    )
    record["created_at"] = datetime.now(timezone.utc)

    volunteers_collection.insert_one(record)

    return {
        "message": "Volunteer registered successfully",
        "data": serialize(volunteers_collection.find_one(
            {"volunteer_id": record["volunteer_id"]}
        ))
    }


# -------------------------------
# HELP REQUESTS + VOLUNTEER NOTIFICATIONS
# -------------------------------

@app.get("/api/requests")
def get_requests():
    return get_records(requests_collection)


@app.post("/api/requests")
def add_request(data: RequestInput):
    record = data.model_dump()

    record["request_id"] = next_id(
        requests_collection, "request_id", "REQ"
    )
    record["status"] = "Pending"
    record["created_at"] = datetime.now(timezone.utc)

    # Save the request first
    requests_collection.insert_one(record)

    # Find available volunteers in the same location
    matching_volunteers = list(
        volunteers_collection.find({
            "status": "Available",
            "location": {
                "$regex": f"^{record['location'].strip()}$",
                "$options": "i"
            }
        })
    )

    notified = []

    # Create one notification per matching volunteer
    for volunteer in matching_volunteers:
        notification = {
            "notification_id": str(ObjectId()),
            "volunteer_id": volunteer["volunteer_id"],
            "request_id": record["request_id"],
            "title": "New Emergency Help Request",
            "message": (
                f"{record['resource']} required at "
                f"{record['location']}. "
                f"Quantity: {record['quantity']}. "
                f"Priority: {record['priority']}."
            ),
            "location": record["location"],
            "priority": record["priority"],
            "is_read": False,
            "created_at": datetime.now(timezone.utc)
        }

        notifications_collection.insert_one(notification)
        notified.append(volunteer["volunteer_id"])

    saved = requests_collection.find_one(
        {"request_id": record["request_id"]}
    )

    return {
        "message": "Help request recorded successfully",
        "request": serialize(saved),
        "notified_volunteers": notified,
        "notification_count": len(notified)
    }


# -------------------------------
# VOLUNTEER NOTIFICATIONS
# -------------------------------

@app.get("/api/notifications/{volunteer_id}")
def get_notifications(volunteer_id: str):
    notifications = notifications_collection.find(
        {"volunteer_id": volunteer_id}
    ).sort("created_at", -1)

    return [serialize(x) for x in notifications]


@app.get("/api/notifications/{volunteer_id}/unread-count")
def unread_count(volunteer_id: str):
    count = notifications_collection.count_documents({
        "volunteer_id": volunteer_id,
        "is_read": False
    })

    return {"unread_count": count}


@app.patch("/api/notifications/{notification_id}/read")
def mark_notification_read(notification_id: str):
    result = notifications_collection.update_one(
        {"notification_id": notification_id},
        {"$set": {"is_read": True}}
    )

    if result.matched_count == 0:
        raise HTTPException(404, "Notification not found")

    return {"message": "Notification marked as read"}


# -------------------------------
# DISTRIBUTION
# -------------------------------

@app.get("/api/distributions")
def get_distributions():
    return get_records(distributions_collection)


@app.post("/api/distributions")
def add_distribution(data: DistributionInput):
    record = data.model_dump()
    record["distribution_id"] = next_id(
        distributions_collection, "distribution_id", "DST"
    )
    record["status"] = "In Transit"
    record["created_at"] = datetime.now(timezone.utc)

    distributions_collection.insert_one(record)

    return {
        "message": "Distribution recorded successfully",
        "data": serialize(distributions_collection.find_one(
            {"distribution_id": record["distribution_id"]}
        ))
    }


# -------------------------------
# INCIDENT REPORTING / SOS
# -------------------------------

@app.get("/api/incidents")
def get_incidents():
    return get_records(incidents_collection)


@app.post("/api/incidents")
def add_incident(data: IncidentInput):
    record = data.model_dump()

    record["incident_id"] = next_id(
        incidents_collection, "incident_id", "INC"
    )
    record["status"] = "Reported"
    record["created_at"] = datetime.now(timezone.utc)

    incidents_collection.insert_one(record)

    return {
        "message": "Incident reported successfully",
        "data": serialize(incidents_collection.find_one(
            {"incident_id": record["incident_id"]}
        ))
    }


# -------------------------------
# DISASTER ALERTS
# -------------------------------

@app.get("/api/alerts")
def get_alerts():
    return get_records(alerts_collection)


@app.post("/api/alerts")
def add_alert(data: dict):
    record = {
        **data,
        "created_at": datetime.now(timezone.utc)
    }

    result = alerts_collection.insert_one(record)

    return {
        "message": "Alert published successfully",
        "id": str(result.inserted_id)
    }


# -------------------------------
# EMERGENCY CONTACTS
# -------------------------------

@app.get("/api/contacts/{user_id}")
def get_contacts(user_id: str):
    return [
        serialize(x)
        for x in contacts_collection.find({"user_id": user_id})
    ]


@app.post("/api/contacts")
def add_contact(data: dict):
    if not data.get("user_id") or not data.get("phone"):
        raise HTTPException(400, "User ID and phone are required")

    result = contacts_collection.insert_one(data)

    return {
        "message": "Emergency contact saved",
        "id": str(result.inserted_id)
    }


# -------------------------------
# SHELTERS
# -------------------------------

@app.get("/api/shelters")
def get_shelters():
    return get_records(shelters_collection)


@app.post("/api/shelters")
def add_shelter(data: dict):
    if not data.get("shelter_name"):
        raise HTTPException(400, "Shelter name is required")

    data["created_at"] = datetime.now(timezone.utc)
    result = shelters_collection.insert_one(data)

    return {
        "message": "Shelter added successfully",
        "id": str(result.inserted_id)
    }
