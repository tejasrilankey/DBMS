
import os
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI")
DATABASE_NAME = os.getenv("DATABASE_NAME", "reliefgrid")

client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)

# Verify the MongoDB connection
client.admin.command("ping")

db = client[DATABASE_NAME]

# Collections
users_collection = db["users"]
locations_collection = db["locations"]
resources_collection = db["resources"]
volunteers_collection = db["volunteers"]
requests_collection = db["requests"]
distributions_collection = db["distributions"]
incidents_collection = db["incident_reports"]
alerts_collection = db["disaster_alerts"]
contacts_collection = db["emergency_contacts"]
shelters_collection = db["shelters"]
notifications_collection = db["notifications"]

# Prevent duplicate IDs
users_collection.create_index("user_id", unique=True)
requests_collection.create_index("request_id", unique=True)
volunteers_collection.create_index("volunteer_id", unique=True)
locations_collection.create_index("location_id", unique=True)

print("MongoDB connected successfully!")
